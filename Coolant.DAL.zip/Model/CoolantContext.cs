namespace Coolant.DAL.Model
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class CoolantContext : DbContext
    {
        public CoolantContext()
            : base("name=CoolantContext")
        {
        }

        public virtual DbSet<AuditChangeType> AuditChangeTypes { get; set; }
        public virtual DbSet<AuditLogRecord> AuditLogRecords { get; set; }
        public virtual DbSet<AuditLog> AuditLogs { get; set; }
        public virtual DbSet<LeanWorkCenter> LeanWorkCenters { get; set; }
        public virtual DbSet<Log4NetLog> Log4NetLog { get; set; }
        public virtual DbSet<Machines> Machines { get; set; }
        public virtual DbSet<MeasurementLog> MeasurementLogs { get; set; }
        public virtual DbSet<Rols> Rols { get; set; }
        public virtual DbSet<Users> Users { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Machines>()
                .Property(e => e.ConcentrationMinimun)
                .HasPrecision(10, 2);

            modelBuilder.Entity<Machines>()
                .Property(e => e.ConcentrationMaximun)
                .HasPrecision(10, 2);

            modelBuilder.Entity<Machines>()
                .Property(e => e.PHMinimun)
                .HasPrecision(10, 2);

            modelBuilder.Entity<Machines>()
                .Property(e => e.PHMaximun)
                .HasPrecision(10, 2);

            modelBuilder.Entity<MeasurementLog>()
                .Property(e => e.ConcentrationValue)
                .HasPrecision(10, 2);

            modelBuilder.Entity<MeasurementLog>()
                .Property(e => e.MinConcentration)
                .HasPrecision(10, 0);

            modelBuilder.Entity<MeasurementLog>()
                .Property(e => e.MaxConcentration)
                .HasPrecision(10, 0);

            modelBuilder.Entity<MeasurementLog>()
                .Property(e => e.NewConcentrationValue)
                .HasPrecision(10, 0);

            modelBuilder.Entity<MeasurementLog>()
                .Property(e => e.PHValue)
                .HasPrecision(10, 0);

            modelBuilder.Entity<MeasurementLog>()
                .Property(e => e.MinPHValue)
                .HasPrecision(10, 0);

            modelBuilder.Entity<MeasurementLog>()
                .Property(e => e.MaxPHValue)
                .HasPrecision(10, 0);

            modelBuilder.Entity<MeasurementLog>()
                .Property(e => e.NewPHValue)
                .HasPrecision(10, 0);
        }
    }
}
