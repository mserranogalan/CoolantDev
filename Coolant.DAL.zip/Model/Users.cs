namespace Coolant.DAL.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Users")]
    public partial class Users
    {
        [Key]
        public int UserId { get; set; }

        [Required]
        [StringLength(10)]
        public string Badge { get; set; }

        [Required]
        [StringLength(250)]
        public string Name { get; set; }

        public int LeanWorkCenterId { get; set; }

        public int RolId { get; set; }

        public int SupervisorId { get; set; }

        public bool IsActive { get; set; }
    }
}
