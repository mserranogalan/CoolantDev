namespace Coolant.DAL.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Machines")]
    public partial class Machines
    {
        [Key]
        public int MachineId { get; set; }

        [Required]
        [StringLength(250)]
        public string Name { get; set; }

        public int LeanWorkCenterId { get; set; }

        public decimal ConcentrationMinimun { get; set; }

        public decimal ConcentrationMaximun { get; set; }

        public decimal PHMinimun { get; set; }

        public decimal PHMaximun { get; set; }

        public int CAM { get; set; }

        public DateTime CreatedOn { get; set; }

        public int CreatedBy { get; set; }

        public bool IsActive { get; set; }
    }
}
