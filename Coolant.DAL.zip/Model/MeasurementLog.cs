namespace Coolant.DAL.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("MeasurementLog")]
    public partial class MeasurementLog
    {
        [Key]
        public int MeasurementLogId { get; set; }

        public int MachineId { get; set; }

        public int CreatedBy { get; set; }

        public DateTime CreatedOn { get; set; }

        public decimal ConcentrationValue { get; set; }

        public decimal MinConcentration { get; set; }

        public decimal MaxConcentration { get; set; }

        public decimal NewConcentrationValue { get; set; }

        [StringLength(250)]
        public string ConcentrationActionTaken { get; set; }

        public decimal PHValue { get; set; }

        public decimal? MinPHValue { get; set; }

        public decimal? MaxPHValue { get; set; }

        public decimal? NewPHValue { get; set; }

        [StringLength(250)]
        public string PHActionTaken { get; set; }

        public bool CoolantLevel { get; set; }

        public bool? CoolantLevelFixed { get; set; }

        public bool RustPresent { get; set; }

        public bool BadSmell { get; set; }

        [StringLength(250)]
        public string Comments { get; set; }

        public int UserId { get; set; }

        public DateTime AuthorizedOn { get; set; }
    }
}
