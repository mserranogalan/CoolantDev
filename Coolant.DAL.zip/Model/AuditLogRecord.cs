namespace Coolant.DAL.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("AuditLogRecord")]
    public partial class AuditLogRecord
    {
        [Key]
        public int AuditLogRecordId { get; set; }

        public int AuditLogId { get; set; }

        [Required]
        [StringLength(255)]
        public string ColumnName { get; set; }

        [StringLength(4000)]
        public string OriginalValue { get; set; }

        [StringLength(4000)]
        public string NewValue { get; set; }
    }
}
