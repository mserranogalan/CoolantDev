namespace Coolant.DAL.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("AuditLog")]
    public partial class AuditLog
    {
        [Key]
        public int AuditLogId { get; set; }

        [Required]
        [StringLength(255)]
        public string TableName { get; set; }

        [Required]
        [StringLength(50)]
        public string TableKey { get; set; }

        public DateTime AuditDate { get; set; }

        public int AuditChangeTypeId { get; set; }

        public int UserId { get; set; }
    }
}
