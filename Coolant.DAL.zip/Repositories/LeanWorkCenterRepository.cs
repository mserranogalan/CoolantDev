﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using Coolant.DAL.Model;
using log4net;

namespace Coolant.DAL.Repositories
{
    public class LeanWorkCenterRepository : Repository
    {
        private static log4net.ILog Log { get; set; }
        ILog log = log4net.LogManager.GetLogger(typeof(LeanWorkCenterRepository));

        /// <summary>
        /// Method to get all Lean Work Center 
        /// </summary>
        /// <returns></returns>
        public List<LeanWorkCenter> GetAllLeanWorkCenter()
        {
            List<LeanWorkCenter> leanworkcenter = null;
            try
            {
                OpenConnection();
                //leanworkcenter = Db.LeanWorkCenter.Where(a => a.IsActive).OrderBy(a => a.Description).ToList();
                leanworkcenter = Db.LeanWorkCenters.ToList();
            }
            catch (Exception exception)
            {
                leanworkcenter = null;
                log.Error(exception);
            }
            finally
            {
                CloseConnection();
            }

            return leanworkcenter;
        }


        public LeanWorkCenter UpdateLeanWorkCenter(LeanWorkCenter leanWorkCenter)
        {
            LeanWorkCenter entity = null;
            try
            {
                OpenConnection();
                if (leanWorkCenter != null)
                {
                    entity = GetLeanWorkCenterById(leanWorkCenter.LeanWorkCenterId);
                    if (entity != null) {
                        entity.Description = leanWorkCenter.Description;
                        entity.IsActive = leanWorkCenter.IsActive;
                        Db.SaveChanges();
                        Db.Entry(entity).GetDatabaseValues();
                        entity = GetLeanWorkCenterById(entity.LeanWorkCenterId);
                    }
                }
            }
            catch (Exception exception)
            {
                entity = null;
                log.Error(exception);
            }
            finally
            {
                CloseConnection();
            }
            return entity;
        }


        public bool AddLeanWorkCEnter(LeanWorkCenter leanWorkCenter)
        {
            bool success = false;
            try
            {
                OpenConnection();
                if (leanWorkCenter != null)
                {
                    Db.LeanWorkCenters.Add(leanWorkCenter);
                    Db.SaveChanges();
                    success = true;
                }
            }
            catch (Exception exception)
            {
                leanWorkCenter = null;
                log.Error(exception);
            }
            finally
            {
                CloseConnection();
            }

            return success;
        }


        public LeanWorkCenter GetLeanWorkCenterById(int Id)
        {
            LeanWorkCenter leanWorkCenter = null;
            try
            {
                OpenConnection();
                leanWorkCenter = Db.LeanWorkCenters.FirstOrDefault(x => x.LeanWorkCenterId == Id);
            }
            finally
            {
                CloseConnection();
            }
            return leanWorkCenter;
        }


    }
}
