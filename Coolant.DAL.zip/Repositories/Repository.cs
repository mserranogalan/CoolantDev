﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using Coolant.DAL.Model;

namespace Coolant.DAL.Repositories
{
    /// <summary>
    /// Connects to the DB
    /// </summary>
    public abstract class Repository
    {

        protected CoolantContext Db { get; set; }

        /// <summary>
        /// If connection is not open, this will try to open it
        /// </summary>
        public void OpenConnection()
        {
            switch (Db.Database.Connection.State)
            {
                case ConnectionState.Open:
                case ConnectionState.Executing:
                case ConnectionState.Fetching:
                    {
                        break;
                    }

                default:
                    {
                        Db.Database.Connection.Open();
                        break;
                    }
            }
        }

        /// <summary>
        /// If connection is not closed, this will try to close it
        /// </summary>
        public void CloseConnection()
        {
            if (Db.Database.Connection != null && Db.Database.Connection.State != ConnectionState.Closed)
            {
                Db.Database.Connection.Close();
            }
        }


        /// <summary>
        /// Repository Constructor
        /// </summary>
        protected Repository()
        {
            Db = new CoolantContext();
            Db.Database.Connection.Open();
        }


        #region Destructor
        ~Repository()
        {

        }
        #endregion

    }
}
