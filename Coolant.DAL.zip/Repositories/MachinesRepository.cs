﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using Coolant.DAL.Model;
using log4net;
using System.Collections;

namespace Coolant.DAL.Repositories
{
    public class MachinesRepository : Repository
    {
        private static log4net.ILog Log { get; set; }
        ILog log = log4net.LogManager.GetLogger(typeof(MachinesRepository));

        /// <summary>
        /// Method to get all Machines
        /// </summary>
        /// <returns></returns>


        public List<Machines> GetAllMachines()
        //public IEnumerable<Machines> GetAllMachines()
        {
            OpenConnection();

            List<Machines> machines = null;
            //machines = Db.Machines.ToList();
            var result = from a in Db.Machines
                         select new { a.MachineId, a.Name };
            machines = result.AsEnumerable()
                        .Select(o => new Machines
                        {
                            MachineId = o.MachineId,
                            Name = o.Name
                        }).ToList();


            //var Lista = (from mach in Db.Machines
            //             join lwc in Db.LeanWorkCenters on mach.LeanWorkCenterId equals lwc.LeanWorkCenterId into temp
            //             from lwc in temp.DefaultIfEmpty()
            //             select new
            //             {
            //                 mach.MachineId,
            //                 mach.Name,
            //                 lwc.Description,
            //                 mach.ConcentrationMaximun,
            //                 mach.ConcentrationMinimun,
            //                 mach.PHMaximun,
            //                 mach.PHMinimun,
            //                 mach.CAM,
            //                 mach.IsActive
            //             }).ToList();



            CloseConnection();

            return machines;
            //return Lista;
        }


        public Machines UpdateMachines(Machines machines)
        {
            Machines entity = null;
            try
            {
                OpenConnection();
                if (machines != null)
                {
                    entity = GetMachineById(machines.MachineId);
                    if (entity != null)
                    {
                        entity.Name = machines.Name;
                        entity.ConcentrationMinimun = machines.ConcentrationMinimun;
                        entity.ConcentrationMaximun = machines.ConcentrationMaximun;
                        entity.PHMinimun = machines.PHMinimun;
                        entity.PHMaximun = machines.PHMaximun;
                        entity.CreatedOn = DateTime.Now;
                        entity.CreatedBy = machines.CreatedBy;
                        entity.IsActive = machines.IsActive;
                        Db.SaveChanges();
                        Db.Entry(entity).GetDatabaseValues();
                        entity = GetMachineById(entity.MachineId);
                    }
                }
            }
            catch (Exception exception)
            {
                entity = null;
                log.Error(exception);
            }
            finally
            {
                CloseConnection();
            }
            return entity;
        }


        public bool AddMachine(Machines  machines)
        {
            bool success = false;
            try
            {
                OpenConnection();
                if (machines != null)
                {
                    Db.Machines.Add(machines);
                    Db.SaveChanges();
                    success = true;
                }
            }
            catch (Exception exception)
            {
                machines = null;
                log.Error(exception);
            }
            finally
            {
                CloseConnection();
            }
            return success;
        }



        public Machines GetMachineById(int Id)
        {
            Machines machines = null;
            try
            {
                OpenConnection();
                machines = Db.Machines.FirstOrDefault(x => x.MachineId == Id);
            }
            finally
            {
                CloseConnection();
            }
            return machines;
        }


    }
}
