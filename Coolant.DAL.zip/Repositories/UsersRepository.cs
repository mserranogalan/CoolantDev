﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using Coolant.DAL.Model;
using log4net;

namespace Coolant.DAL.Repositories
{
    public class UsersRepository : Repository
    {
        private static log4net.ILog Log { get; set; }
        ILog log = log4net.LogManager.GetLogger(typeof(UsersRepository));

        /// <summary>
        /// Method to get all Users
        /// </summary>
        /// <returns></returns>
        public List<Users> GetAllUsers()
        {
            List<Users> users = null;
            try
            {
                OpenConnection();
                users = Db.Users.ToList();
            }
            catch (Exception exception)
            {
                users = null;
                log.Error(exception);
            }
            finally
            {
                CloseConnection();
            }

            return users;
        }


        public Users UpdateUsers(Users users)
        {
            Users entity = null;
            try
            {
                OpenConnection();
                if (users != null)
                {
                    entity = GetUserById(users.UserId);
                    if (entity != null)
                    {
                        entity.Badge = users.Badge;
                        entity.Name = users.Name;
                        entity.LeanWorkCenterId = users.LeanWorkCenterId;
                        entity.RolId = users.RolId;
                        entity.SupervisorId = users.SupervisorId;
                        entity.IsActive = users.IsActive;
                        Db.SaveChanges();
                        Db.Entry(entity).GetDatabaseValues();
                        entity = GetUserById(entity.UserId);
                    }
                }
            }
            catch (Exception exception)
            {
                entity = null;
                log.Error(exception);
            }
            finally
            {
                CloseConnection();
            }
            return entity;
        }


        public bool AddUser(Users users)
        {
            bool success = false;
            try
            {
                OpenConnection();
                if (users != null)
                {
                    Db.Users.Add(users);
                    Db.SaveChanges();
                    success = true;
                }
            }
            catch (Exception exception)
            {
                users = null;
                log.Error(exception);
            }
            finally
            {
                CloseConnection();
            }
            return success;
        }


        public Users GetUserById(int Id)
        {
            Users machines = null;
            try
            {
                OpenConnection();
                machines = Db.Users.FirstOrDefault(x => x.UserId == Id);
            }
            finally
            {
                CloseConnection();
            }
            return machines;
        }


    }
}
