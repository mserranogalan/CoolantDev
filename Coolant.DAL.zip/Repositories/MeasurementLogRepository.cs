﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using Coolant.DAL.Model;
using log4net;

namespace Coolant.DAL.Repositories
{
    public class MeasurementLogRepository : Repository
    {


    }
}
