﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using Coolant.DAL.Model;
using log4net;

namespace Coolant.DAL.Repositories
{
    public class RolsRepository : Repository
    {
        private static log4net.ILog Log { get; set; }
        ILog log = log4net.LogManager.GetLogger(typeof(LeanWorkCenterRepository));




    }

}
