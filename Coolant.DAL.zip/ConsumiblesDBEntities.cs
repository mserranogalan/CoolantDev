﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.Entity;
using System.Data.Entity.Core;
using System.Data.Entity.Core.EntityClient;
using System.Data.Entity.Core.Objects;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Web;
using Coolant.DAL.Model;

namespace Coolant.DAL
{

    public class ConsumiblesDBEntities
    { }


    //public partial class ConsumiblesDBEntities : CoolantContext
    //{
    //    CoolantContext dbCoolant = new CoolantContext();
    //    private Regex regTableHasGuid = new Regex("^(?<TableName>.+)_(?<Guid>[A-F0-9]{64})$", RegexOptions.Compiled | RegexOptions.Singleline);
    //    private readonly string[] _tablesToIgnore = { "auditlog", "auditlogrecord", "auditchangetype" };
    //    private static Dictionary<string, string> UnpredictiableTableNameToPrimaryKey;
    //    string badge = HttpContext.Current.User.Identity.Name;

    //    public static EntityKey GetEntityKey<T>(DbContext context, T entity)
    //                    where T : class
    //    {
    //        var oc = ((IObjectContextAdapter)context).ObjectContext;
    //        ObjectStateEntry ose;
    //        if (null != entity && oc.ObjectStateManager
    //                                .TryGetObjectStateEntry(entity, out ose))
    //        {
    //            return ose.EntityKey;
    //        }
    //        return null;
    //    }

    //    public static EntityKey GetEntityKey1<T>(DbContext context
    //                                           , DbEntityEntry<T> dbEntityEntry)
    //        where T : class
    //    {
    //        if (dbEntityEntry != null)
    //        {
    //            return GetEntityKey(context, dbEntityEntry.Entity);
    //        }
    //        return null;
    //    }

    //    private Users currentUser
    //    {
    //        get
    //        {
    //            return dbCoolant.Users.FirstOrDefault(x => x.Badge == badge);
    //        }
    //    }

    //    public override int SaveChanges()
    //    {
    //        return this.SaveChanges(false);
    //    }

    //    private int SaveChanges(bool SkipAudit)
    //    {

    //        if (SkipAudit)
    //        {
    //            return base.SaveChanges();
    //        }
    //        else
    //        {

    //            string connectString = ConfigurationManager.ConnectionStrings["CoolantEntities"].ToString();
    //            EntityConnectionStringBuilder builder = new EntityConnectionStringBuilder(connectString);
    //            connectString = builder.ProviderConnectionString;
    //            SqlConnectionStringBuilder source = new SqlConnectionStringBuilder(connectString);
    //            string server = source.DataSource;
    //            string hash = server == "F3ZERO" ? "128048218020210234039093105241135046139173024181" : (server == "T3TSQLDB01") ? "033122198064209176137159214206213174205191252225119009071207242208215066107049019074148040099148" : "188159012184066120210073064064043169226248209114";

    //            if (UnpredictiableTableNameToPrimaryKey == null || UnpredictiableTableNameToPrimaryKey.Keys.Count == 0)
    //            {
    //                UnpredictiableTableNameToPrimaryKey = new Dictionary<string, string>();
    //                UnpredictiableTableNameToPrimaryKey.Add("User", "UserId");
    //            }
    //            DateTime changeTime = DateTime.Now;
    //            int fakeKey = -1;

    //            List<AuditLogs> auditsToAdd = new List<AuditLogs>();
    //            base.ChangeTracker.DetectChanges();
    //            object newObjectValue;
    //            List<DbEntityEntry> dbEntityEntry = base.ChangeTracker.Entries().ToList();
    //            var unModifiedValues = 0;
    //            foreach (DbEntityEntry dbEntry in dbEntityEntry)
    //            {
    //                string originalTableName;
    //                string tableName = originalTableName = dbEntry.Entity.GetType().Name;
    //                if (regTableHasGuid.IsMatch(tableName))
    //                {
    //                    tableName = regTableHasGuid.Match(tableName).Groups["TableName"].Value;
    //                }
    //                if (!this._tablesToIgnore.Any(tableName.ToLower().Contains))
    //                {
    //                    string tableID = null;
    //                    string operationTypeString;
    //                    EntityState operationType = dbEntry.State;
    //                    AuditLogs log;
    //                    switch (operationType)
    //                    {
    //                        case EntityState.Added:
    //                        case EntityState.Modified:

    //                            log = new AuditLogs();
    //                            foreach (string columnName in dbEntry.CurrentValues.PropertyNames)
    //                            {
    //                                string originalValue = null;
    //                                string newValue = null;
    //                                switch (operationType)
    //                                {
    //                                    case EntityState.Added:
    //                                        originalValue = null;
    //                                        break;
    //                                    case EntityState.Modified:
    //                                        newObjectValue = dbEntry.OriginalValues.GetValue<object>(columnName);
    //                                        originalValue = newObjectValue != null ? newObjectValue.ToString() : null;
    //                                        try
    //                                        {
    //                                            tableID = dbEntry.OriginalValues.GetValue<object>(String.Format("{0}Id", tableName)).ToString();
    //                                        }
    //                                        catch
    //                                        {
    //                                            tableID = dbEntry.OriginalValues.GetValue<object>(String.Format("{0}sId", tableName)).ToString();
    //                                        }
    //                                        break;
    //                                }
    //                                switch (operationType)
    //                                {
    //                                    case EntityState.Added:
    //                                    case EntityState.Modified:
    //                                        newObjectValue = dbEntry.CurrentValues.GetValue<object>(columnName);
    //                                        newValue = newObjectValue != null ? newObjectValue.ToString() : null;
    //                                        break;
    //                                }
    //                                if (originalValue != newValue)
    //                                {
    //                                    AuditLogRecords record = new AuditLogRecords();
    //                                    record.ColumnName = columnName;
    //                                    record.NewValue = newValue;
    //                                    record.OriginalValue = originalValue;
    //                                    log.AuditLogRecords.Add(record);
    //                                }
    //                            }
    //                            operationTypeString = operationType.ToString();

    //                            log.AuditChangeTypes = dbCoolant.AuditChangeTypes.FirstOrDefault(x => x.Name == operationTypeString);
    //                            log.AuditDate = changeTime;
    //                            log.TableKey = tableID != null ? tableID : fakeKey.ToString();
    //                            log.TableName = tableName;
    //                            log.UserId = currentUser.UserId;
    //                            auditsToAdd.Add(log);
    //                            fakeKey--;
    //                            break;

    //                        case EntityState.Deleted:
    //                            log = new AuditLogs();
    //                            foreach (string columnName in dbEntry.OriginalValues.PropertyNames)
    //                            {
    //                                string originalValue = null;
    //                                string newValue = null;
    //                                newObjectValue = dbEntry.OriginalValues.GetValue<object>(columnName);
    //                                originalValue = newObjectValue != null ? newObjectValue.ToString() : null;
    //                                try
    //                                {
    //                                    tableID = dbEntry.OriginalValues.GetValue<object>(String.Format("{0}Id", tableName)).ToString();
    //                                }
    //                                catch
    //                                {
    //                                    tableID = dbEntry.OriginalValues.GetValue<object>(String.Format("{0}sId", tableName)).ToString();
    //                                }
    //                                if (originalValue != newValue)
    //                                {
    //                                    AuditLogRecords record = new AuditLogRecords();
    //                                    record.ColumnName = columnName;
    //                                    record.NewValue = newValue;
    //                                    record.OriginalValue = originalValue;
    //                                    log.AuditLogRecords.Add(record);
    //                                }
    //                            }
    //                            operationTypeString = operationType.ToString();
    //                            log.AuditChangeTypes = dbCoolant.AuditChangeTypes.FirstOrDefault(s => s.Name == operationTypeString);
    //                            log.AuditDate = changeTime;
    //                            log.TableKey = tableID;
    //                            log.TableName = tableName;
    //                            log.Users = currentUser;
    //                            log.UserId = currentUser.UserId;
    //                            auditsToAdd.Add(log);
    //                            fakeKey--;
    //                            break;
    //                        case EntityState.Unchanged:
    //                            unModifiedValues++;
    //                            break;
    //                    }
    //                }
    //            }
    //            int result = 0;
    //            try
    //            {
    //                result = base.SaveChanges();
    //            }
    //            catch (DbEntityValidationException ex)
    //            {
    //                foreach (DbEntityValidationResult dbError in ex.EntityValidationErrors)
    //                {
    //                    foreach (DbValidationError dbValidError in dbError.ValidationErrors)
    //                    {
    //                        Exception dbException = new Exception(String.Format("Properity: {0} Error: {1}", dbValidError.PropertyName, dbValidError.ErrorMessage));
    //                    }
    //                }
    //                throw ex;
    //            }
    //            catch (Exception ex)
    //            {
    //                throw ex;
    //            }
    //            fakeKey = -1;
    //            if (unModifiedValues == dbEntityEntry.Count)
    //            {
    //                return 1;
    //            }
    //            foreach (DbEntityEntry dbEntry in dbEntityEntry)
    //            {
    //                string originalTableName;
    //                string tableName = originalTableName = dbEntry.Entity.GetType().Name;
    //                if (regTableHasGuid.IsMatch(tableName))
    //                {
    //                    tableName = regTableHasGuid.Match(tableName).Groups["TableName"].Value;
    //                }
    //                if (!this._tablesToIgnore.Any(tableName.ToLower().Contains))
    //                {
    //                    AuditLogs log = auditsToAdd.FirstOrDefault(s => s.TableName == tableName && s.TableKey == fakeKey.ToString());
    //                    if (log != null)
    //                    {
    //                        try
    //                        {
    //                            log.TableKey = GetPrimaryKeyValue(dbEntry).ToString();

    //                        }
    //                        catch (Exception ex)
    //                        {
    //                            try
    //                            {
    //                                log.TableKey = UnpredictiableTableNameToPrimaryKey.Keys.Contains(tableName) ?
    //                                    dbEntry.CurrentValues.GetValue<object>(UnpredictiableTableNameToPrimaryKey[tableName]).ToString() :
    //                                    dbEntry.CurrentValues.GetValue<object>(String.Format("{0}Id", tableName)).ToString();
    //                            }
    //                            catch
    //                            {
    //                                log.TableKey = "-1";
    //                            }
    //                        }

    //                        foreach (AuditLogRecords record in log.AuditLogRecords)
    //                        {
    //                            foreach (string columnName in dbEntry.CurrentValues.PropertyNames)
    //                            {
    //                                if ((columnName == record.ColumnName) && (record.NewValue != dbEntry.CurrentValues.GetValue<object>(columnName).ToString()))
    //                                {
    //                                    record.NewValue = dbEntry.CurrentValues.GetValue<object>(columnName).ToString();
    //                                }
    //                            }
    //                        }
    //                        fakeKey--;
    //                    }
    //                }
    //                dbEntry.State = EntityState.Unchanged;
    //            }
    //            return UpdateAuditLogs(auditsToAdd) + result;
    //        }
    //    }

    //    object GetPrimaryKeyValue(DbEntityEntry entry)
    //    {
    //        var objectStateEntry = ((IObjectContextAdapter)this).ObjectContext.ObjectStateManager.GetObjectStateEntry(entry.Entity);
    //        return objectStateEntry.EntityKey.EntityKeyValues[0].Value;
    //    }


    //    private int UpdateAuditLogs(List<AuditLogs> auditsToAdd)
    //    {
    //        try
    //        {
    //            int auditRecordCount = 0;
    //            foreach (AuditLogs auditLog in auditsToAdd)
    //            {
    //                AuditLogs auditLogCopy = new AuditLogs();
    //                auditLogCopy.AuditChangeTypes = dbCoolant.AuditChangeTypes.FirstOrDefault(x => x.AuditChangeTypeId == auditLog.AuditChangeTypes.AuditChangeTypeId);
    //                auditLogCopy.AuditDate = auditLog.AuditDate;
    //                auditLogCopy.TableKey = auditLog.TableKey;
    //                auditLogCopy.TableName = auditLog.TableName;
    //                auditLogCopy.Users = dbCoolant.Users.FirstOrDefault(s => s.UserId == auditLog.UserId);

    //                if (auditLog.AuditLogRecords.Count > 0)
    //                {
    //                    dbCoolant.AuditLogs.Add(auditLogCopy);
    //                    foreach (AuditLogRecords auditLogRecord in auditLog.AuditLogRecords)
    //                    {
    //                        AuditLogRecords auditLogRecordCopy = new AuditLogRecords();
    //                        auditLogCopy.AuditLogRecords.Add(auditLogRecordCopy);
    //                        auditLogRecordCopy.ColumnName = auditLogRecord.ColumnName;
    //                        auditLogRecordCopy.NewValue = auditLogRecord.NewValue;
    //                        auditLogRecordCopy.OriginalValue = auditLogRecord.OriginalValue;
    //                    }
    //                    auditRecordCount++;
    //                }
    //            }
    //            if (auditRecordCount > 0)
    //            {
    //                return dbCoolant.SaveChanges();
    //            }
    //            else
    //            {
    //                return 0;
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            throw ex;
    //        }
    //    }


    //}

}
