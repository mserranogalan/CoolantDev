﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.Data.Entity.Core;
using System.Data.Entity.Core.Objects;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Text.RegularExpressions;
using System.Configuration;
using System.Data.Entity.Core.EntityClient;
using System.Data.SqlClient;
using System.Web;
using Coolant.DAL.Model;

namespace Coolant.DAL
{

    public class DBAudit
    { }

    //public partial class DBAudit : CoolantContext
    //{
    //    private DBAudit DB { get; set; }

    //    private Regex regTableHasGuid = new Regex("^(?<TableName>.+)_(?<Guid>[A-F0-9]{64})$", RegexOptions.Compiled | RegexOptions.Singleline);
    //    private readonly string[] _tablesToIgnore = { "auditlog", "auditlogrecord", "auditchangetype" };
    //    private static Dictionary<string, string> UnpredictiableTableNameToPrimaryKey;
    //    string badge = System.Web.HttpContext.Current.User.Identity.Name;

    //    public static EntityKey GetEntityKey<T>(DbContext context, T entity)
    //    where T : class
    //    {
    //        var oc = ((IObjectContextAdapter)context).ObjectContext;
    //        ObjectStateEntry ose;
    //        if (null != entity && oc.ObjectStateManager
    //                                .TryGetObjectStateEntry(entity, out ose))
    //        {
    //            return ose.EntityKey;
    //        }
    //        return null;
    //    }

    //    public static EntityKey GetEntityKey1<T>(DbContext context
    //                                           , DbEntityEntry<T> dbEntityEntry)
    //        where T : class
    //    {
    //        if (dbEntityEntry != null)
    //        {
    //            return GetEntityKey(context, dbEntityEntry.Entity);
    //        }
    //        return null;
    //    }

    //    private Users currentUser
    //    {
    //        get
    //        {
    //            return DB.Users.FirstOrDefault(x => x.Badge == badge);
    //        }
    //    }

    //    public static object HttpContext { get; private set; }

    //    public override int SaveChanges()
    //    {
    //        return this.SaveChanges(false);
    //    }

    //    public int SaveChanges(bool SkipAudit)
    //    {
    //        if (SkipAudit)
    //        {
    //            return base.SaveChangesAsync().Result;
    //        }
    //        else
    //        {
    //            //string connectString = ConfigurationManager.ConnectionStrings["ConsumiblesDBEntities"].ToString();
    //            // EntityConnectionStringBuilder builder = new EntityConnectionStringBuilder(connectString);
    //            // connectString = builder.ProviderConnectionString;
    //            // SqlConnectionStringBuilder source = new SqlConnectionStringBuilder(connectString);
    //            // string server = source.DataSource;
    //            //string hash = server == "F3ZERO" ? "128048218020210234039093105241135046139173024181" : "188159012184066120210073064064043169226248209114";

    //            //Development and Test
    //            DB = new DBAudit();

    //            if (UnpredictiableTableNameToPrimaryKey == null || UnpredictiableTableNameToPrimaryKey.Keys.Count == 0)
    //            {
    //                UnpredictiableTableNameToPrimaryKey = new Dictionary<string, string>();
    //                UnpredictiableTableNameToPrimaryKey.Add("Employees", "EmployeeId");
    //            }
    //            bool letterSRemoved = false;
    //            DateTime changeTime = DateTime.Now;
    //            int fakeKey = -1;
    //            List<AuditLogs> auditsToAdd = new List<AuditLogs>();
    //            base.ChangeTracker.DetectChanges();
    //            object newObjectValue;
    //            List<DbEntityEntry> dbEntityEntry = base.ChangeTracker.Entries().ToList();
    //            foreach (DbEntityEntry dbEntry in dbEntityEntry)
    //            {
    //                string originalTableName;
    //                string tableName = originalTableName = dbEntry.Entity.GetType().Name;
    //                if (regTableHasGuid.IsMatch(tableName))
    //                {
    //                    tableName = regTableHasGuid.Match(tableName).Groups["TableName"].Value;
    //                }
    //                if (!this._tablesToIgnore.Any(tableName.ToLower().Contains))
    //                {
    //                    string tableID = null;
    //                    string operationTypeString;
    //                    EntityState operationType = dbEntry.State;
    //                    AuditLogs log;
    //                    switch (operationType)
    //                    {
    //                        case EntityState.Added:
    //                        case EntityState.Modified:

    //                            log = new AuditLogs();
    //                            foreach (string columnName in dbEntry.CurrentValues.PropertyNames)
    //                            {
    //                                string originalValue = null;
    //                                string newValue = null;
    //                                switch (operationType)
    //                                {
    //                                    case EntityState.Added:
    //                                        originalValue = null;
    //                                        break;
    //                                    case EntityState.Modified:
    //                                        if (tableName.Substring(tableName.Length - 1) == "s")
    //                                        {
    //                                            tableName = tableName.Substring(0, tableName.Length - 1);
    //                                            letterSRemoved = true;
    //                                        }


    //                                        newObjectValue = dbEntry.OriginalValues.GetValue<object>(columnName);
    //                                        originalValue = newObjectValue != null ? newObjectValue.ToString() : null;
    //                                        try
    //                                        {
    //                                            tableID = dbEntry.OriginalValues.GetValue<object>(String.Format("{0}Id", tableName)).ToString();
    //                                        }
    //                                        catch
    //                                        {
    //                                            tableID = dbEntry.OriginalValues.GetValue<object>(String.Format("{0}sId", tableName)).ToString();
    //                                        }
    //                                        break;
    //                                }
    //                                switch (operationType)
    //                                {
    //                                    case EntityState.Added:
    //                                    case EntityState.Modified:
    //                                        newObjectValue = dbEntry.CurrentValues.GetValue<object>(columnName);
    //                                        newValue = newObjectValue != null ? newObjectValue.ToString() : null;
    //                                        break;
    //                                }
    //                                if (originalValue != newValue)
    //                                {
    //                                    AuditLogRecords record = new AuditLogRecords();
    //                                    record.ColumnName = columnName;
    //                                    record.NewValue = newValue;
    //                                    record.OriginalValue = originalValue;
    //                                    log.AuditLogRecords.Add(record);
    //                                }
    //                            }
    //                            operationTypeString = operationType.ToString();
    //                            log.AuditChangeTypes = DB.AuditChangeTypes.FirstOrDefault(x => x.Name == operationTypeString);
    //                            log.AuditDate = changeTime;
    //                            log.TableKey = tableID != null ? tableID : fakeKey.ToString();
    //                            log.TableName = letterSRemoved ? tableName + "s" : tableName;
    //                            log.Users = currentUser;
    //                            log.UserId = currentUser.UserId;
    //                            auditsToAdd.Add(log);
    //                            fakeKey--;
    //                            break;

    //                        case EntityState.Deleted:
    //                            log = new AuditLogs();
    //                            foreach (string columnName in dbEntry.OriginalValues.PropertyNames)
    //                            {
    //                                string originalValue = null;
    //                                string newValue = null;
    //                                newObjectValue = dbEntry.OriginalValues.GetValue<object>(columnName);
    //                                originalValue = newObjectValue != null ? newObjectValue.ToString() : null;
    //                                try
    //                                {
    //                                    tableID = dbEntry.OriginalValues.GetValue<object>(String.Format("{0}Id", tableName)).ToString();
    //                                }
    //                                catch
    //                                {
    //                                    tableID = dbEntry.OriginalValues.GetValue<object>(String.Format("{0}sId", tableName)).ToString();
    //                                }
    //                                if (originalValue != newValue)
    //                                {
    //                                    AuditLogRecords record = new AuditLogRecords();
    //                                    record.ColumnName = columnName;
    //                                    record.NewValue = newValue;
    //                                    record.OriginalValue = originalValue;
    //                                    log.AuditLogRecords.Add(record);
    //                                }
    //                            }
    //                            operationTypeString = operationType.ToString();
    //                            log.AuditChangeTypes = DB.AuditChangeTypes.First(s => s.Name == operationTypeString);
    //                            log.AuditDate = changeTime;
    //                            log.TableKey = tableID;
    //                            log.TableName = tableName;
    //                            log.Users = currentUser;
    //                            log.UserId = currentUser.UserId;
    //                            auditsToAdd.Add(log);
    //                            fakeKey--;
    //                            break;
    //                    }
    //                }
    //            }
    //            int result = 0;
    //            try
    //            {
    //                result = base.SaveChangesAsync().Result;
    //            }
    //            catch (DbEntityValidationException ex)
    //            {
    //                foreach (DbEntityValidationResult dbError in ex.EntityValidationErrors)
    //                {
    //                    foreach (DbValidationError dbValidError in dbError.ValidationErrors)
    //                    {
    //                        Exception dbException = new Exception(String.Format("Properity: {0} Error: {1}", dbValidError.PropertyName, dbValidError.ErrorMessage));
    //                    }
    //                }
    //                throw ex;
    //            }
    //            catch (Exception ex)
    //            {
    //                throw ex;
    //            }
    //            fakeKey = -1;
    //            foreach (DbEntityEntry dbEntry in dbEntityEntry)
    //            {
    //                string originalTableName;
    //                string tableName = originalTableName = dbEntry.Entity.GetType().Name;
    //                if (regTableHasGuid.IsMatch(tableName))
    //                {
    //                    tableName = regTableHasGuid.Match(tableName).Groups["TableName"].Value;
    //                }
    //                if (!this._tablesToIgnore.Any(tableName.ToLower().Contains))
    //                {
    //                    AuditLogs log = auditsToAdd.FirstOrDefault(s => s.TableName == tableName && s.TableKey == fakeKey.ToString());
    //                    if (log != null)
    //                    {
    //                        try
    //                        {
    //                            log.TableKey = GetPrimaryKeyValue(dbEntry).ToString();

    //                        }
    //                        catch (Exception ex)
    //                        {
    //                            try
    //                            {
    //                                log.TableKey = UnpredictiableTableNameToPrimaryKey.Keys.Contains(tableName) ?
    //                                    dbEntry.CurrentValues.GetValue<object>(UnpredictiableTableNameToPrimaryKey[tableName]).ToString() :
    //                                    dbEntry.CurrentValues.GetValue<object>(String.Format("{0}Id", tableName)).ToString();
    //                            }
    //                            catch
    //                            {
    //                                log.TableKey = "-1";
    //                            }
    //                        }

    //                        foreach (AuditLogRecords record in log.AuditLogRecords)
    //                        {
    //                            foreach (string columnName in dbEntry.CurrentValues.PropertyNames)
    //                            {
    //                                if ((columnName == record.ColumnName) && (record.NewValue != dbEntry.CurrentValues.GetValue<object>(columnName).ToString()))
    //                                {
    //                                    record.NewValue = dbEntry.CurrentValues.GetValue<object>(columnName).ToString();
    //                                }
    //                            }
    //                        }
    //                        fakeKey--;
    //                    }
    //                }
    //                dbEntry.State = EntityState.Unchanged;
    //            }
    //            return UpdateAuditLogs(auditsToAdd) + result;
    //        }
    //    }

    //    object GetPrimaryKeyValue(DbEntityEntry entry)
    //    {
    //        var objectStateEntry = ((IObjectContextAdapter)this).ObjectContext.ObjectStateManager.GetObjectStateEntry(entry.Entity);
    //        return objectStateEntry.EntityKey.EntityKeyValues[0].Value;
    //    }


    //    private int UpdateAuditLogs(List<AuditLogs> auditsToAdd)
    //    {
    //        try
    //        {
    //            int auditRecordCount = 0;
    //            foreach (AuditLogs auditLog in auditsToAdd)
    //            {
    //                AuditLogs auditLogCopy = new AuditLogs();
    //                auditLogCopy.AuditChangeTypes = DB.AuditChangeTypes.FirstOrDefault(x => x.AuditChangeTypeId == auditLog.AuditChangeTypeId);
    //                auditLogCopy.AuditDate = auditLog.AuditDate;
    //                auditLogCopy.TableKey = auditLog.TableKey;
    //                auditLogCopy.TableName = auditLog.TableName;
    //                auditLogCopy.Users = DB.Users.First(s => s.UserId == auditLog.UserId);
    //                if (auditLog.AuditLogRecords.Count > 0)
    //                {
    //                    DB.AuditLogs.Add(auditLogCopy);
    //                    foreach (AuditLogRecords auditLogRecord in auditLog.AuditLogRecords)
    //                    {
    //                        AuditLogRecords auditLogRecordCopy = new AuditLogRecords();
    //                        auditLogCopy.AuditLogRecords.Add(auditLogRecordCopy);
    //                        auditLogRecordCopy.ColumnName = auditLogRecord.ColumnName;
    //                        auditLogRecordCopy.NewValue = auditLogRecord.NewValue;
    //                        auditLogRecordCopy.OriginalValue = auditLogRecord.OriginalValue;
    //                    }
    //                    auditRecordCount++;
    //                }
    //            }
    //            if (auditRecordCount > 0)
    //            {
    //                return DB.SaveChanges(true);
    //            }
    //            else
    //            {
    //                return 0;
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            throw ex;
    //        }
    //    }


    //}

}
