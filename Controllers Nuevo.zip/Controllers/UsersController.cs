﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using log4net;
using SolarApp.DataAccess.Repositories;
using SolarApp.Context;
using System.Threading;
using Coolant.BLL.Contexts;
using Coolant.BLL.ViewModels;
using Newtonsoft.Json;
using System.Collections;

namespace Coolant.Controllers
{
    public class UsersController : Controller
    {
        private static readonly ILog Logger = LogManager.GetLogger(System.Environment.MachineName);
        private readonly UsersContext _usersContext;
        private List<UsersVM> Users;
        public IEnumerable LWC;
        public IEnumerable Rols;
        public IEnumerable Supervisors;

        public UsersController()
        {
            _usersContext = new UsersContext();
        }

        public ActionResult UsersPage()
        {
            return View();
        }


        public ActionResult GetAllUsers()
        {
            try
            {
                Users = _usersContext.GetAllUsers();
            }
            catch (Exception exception)
            {
                Logger.Error(exception);
            }
            return Json(Users, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetAllActiveLeanWorkCenter()
        {
            try
            {
                LWC = _usersContext.GetAllActiveLeanWorkCenter();
            }
            catch (Exception exception)
            {
                Logger.Error(exception);
            }
            return Json(LWC, JsonRequestBehavior.AllowGet);
        }


        public ActionResult GetAllActiveRols()
        {
            try
            {
                Rols = _usersContext.GetAllActiveRols();
            }
            catch (Exception exception)
            {
                Logger.Error(exception);
            }
            return Json(Rols, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetAllActiveSupervisors()
        {
            try
            {
                Supervisors = _usersContext.GetAllActiveSupervisors();
            }
            catch (Exception exception)
            {
                Logger.Error(exception);
            }
            return Json(Supervisors, JsonRequestBehavior.AllowGet);
        }


        public ActionResult UpdateUsers(UsersVM users)
        {
            return Json(_usersContext.UpdateUsers(users));
        }

        public ActionResult AddUser(UsersVM users)
        {
            return Json(_usersContext.AddUser(users));
        }

        public ActionResult Index()
        {
            try
            {
                Users = _usersContext.GetAllUsers();
            }
            catch (Exception exception)
            {
                Logger.Error(exception);
            }
            return Json(Users, JsonRequestBehavior.AllowGet);
        }

   









    }
}
