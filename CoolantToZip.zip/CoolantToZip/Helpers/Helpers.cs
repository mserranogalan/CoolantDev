﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace Coolant.Helpers
{
    public static class HtmlHelpers
    {
        public static MvcHtmlString IsActive(this System.Web.Mvc.HtmlHelper htmlHelper, string action, string controller)
        {
            RouteData routeData = htmlHelper.ViewContext.RouteData;

            string routeAction = routeData.Values["action"].ToString();
            string routeController = routeData.Values["controller"].ToString();

            bool returnActive = (controller == routeController && action == routeAction);

            return new MvcHtmlString(returnActive ? "active" : "");
        }
    }
}