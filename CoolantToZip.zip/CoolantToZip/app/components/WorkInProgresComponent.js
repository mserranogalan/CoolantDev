﻿Vue.use(WorkInProgresService);
Vue.use(Functions);
var KanbanTest;
Vue.component('WipComponent', {
    components: { Multiselect: window.VueMultiselect.default, DxDataGrid: DxDataGrid },
    template: '#Wip-Template',
    replace: true,
    data: function () {
        var self = this;
        return {
            workInProgressItemsInBoards: [],
            products: [
                       { ProductId: 2, Name: 'Saturn' },
                       { ProductId: 3, Name: 'CED Cat150' },
                       { ProductId: 4, Name: 'HED Cat150' },
                       { ProductId: 5, Name: 'CED T70/Titan' },
                       { ProductId: 1, Name: 'HED T70/Mars' },
                       { ProductId: 6, Name: 'HED Titan' },
                       { ProductId: 8, Name: 'Intl SubAssys' },
                       { ProductId: 9, Name: 'Field Repair' },
            ],
            productSelected: { ProductId: 2, Name: 'Saturn' },
            kanbaItemClicked: '',
            workInProgressLocations: [],
            slotNumberKanbanItemSelected: '',
            userInformation: []
        };
    },

    created: function () {
        var self = this;
        self.SetUserInformation();
        self.GetWorkInProgress("2");
    },
    beforeDestroy: function () {

    },
    mounted: function () {
        self = this;
        self.GenerateKanbanInstance();
        $(".contextMenu").dxContextMenu({
            dataSource: [
                    { text: ' Move to Ready-To-Ship', icon: 'fa fa-cubes' },
                    { text: ' Move to Shippped-To-Solar-Facility', icon: 'fa fa-truck' }
            ],
            width: 200,
            target: "#subAssemblyOptions",
            itemTemplate: function (itemData, itemIndex, itemElement) {
                var template = $('<div></div>');
                if (itemData.icon) {
                    template.append('<span class="' + itemData.icon + '"><span>');
                }
                if (itemData.items) {
                    template.append('<span class="dx-icon-spinright"><span>');
                }
                template.append(itemData.text);
                return template;
            },
            onItemClick: function (e) {
                if (!e.itemData.items) {
                    if (e.itemData.text == ' Move to Ready-To-Ship') {
                        self.MoveToReadyToShip(self.slotNumberKanbanItemSelected);
                    }
                    else {
                        self.MoveToShippedToSolarFacility(self.slotNumberKanbanItemSelected);
                    }
                }
            }
        });
    },
    updated: function () {
    },
    methods: {
        GenerateKanbanInstance: function () {
            KanbanTest = new jKanban({
                element: '#myKanban',
                gutter: '10px',
                click: function (el) {
                    $(".kanban-item span").click(function (e) {
                        self.MoveSlotOutOfWip(el.dataset.eid);
                        e.stopPropagation();
                    });
                    self.kanbaItemClicked = el.dataset.eid;
                },
                dropEl: function (el, target, source, sibling) {
                    self.MoveItemOnBoards(el.dataset.eid, target.parentNode.attributes[0].value, source.parentNode.attributes[0].value);
                },               
                boards: [],
                dragBoards: false,
            });

            KanbanTest.dragBoards = false;
        },
        GetWorkInProgress: function (productionPath) {
            var self = this;
            this.$GetWorkInProgresService(productionPath).then(function (result) {
                if (result.data.ResponseType == ResponseType.Success) {
                    self.workInProgressItemsInBoards = result.data.Content;
                    self.CreateBoards(self.workInProgressItemsInBoards);
                }
                else {
                    ShowMessage(result.data.ResponseType, result.data.Message)
                }
            },
            function (error) {
                console.log(error);
            });
        },
        CreateBoards: function (wipLocations) {
            var self = this;
            $('#myKanban .kanban-container').empty();
            self.GenerateKanbanInstance();
            for (var i = 0; i < wipLocations.length; i++) {
                KanbanTest.addBoards([wipLocations[i]]);
            }
            $(".kanban-item").append("<span class='tooltipped' data-tooltip='Move out of WIP'>x</span>");
            $(".kanban-item").attr('id', 'subAssemblyOptions');
            $('.tooltipped').tooltip();
            $('.kanban-item').mousedown(function (event) {
                self.slotNumberKanbanItemSelected = event.target.dataset.eid;
            });
            self.ColorNumberOfItemsInBoardsTitle();
            self.EnableMoveItemsInKanban();
        },
        MoveItemOnBoards: function (slotNumber, destination, origin) {
            var self = this;
            var indexOriginLocation = self.workInProgressItemsInBoards.findIndex(function (x) { return x.id === origin;});
            var indexDestinationLocation = self.workInProgressItemsInBoards.findIndex(function (x) { return x.id === destination;});
            var stepsInBoard = Math.abs(indexDestinationLocation - indexOriginLocation);

            if (indexDestinationLocation < indexOriginLocation) {
                this.$MoveWipBackwardService(slotNumber, stepsInBoard).then(function (result) {
                    ShowMessage(result.data.ResponseType, result.data.Message)
                },
                function (error) {
                    console.log(error);
                });
            }
            else {
                this.$MoveWipForwardService(slotNumber, stepsInBoard).then(function (result) {
                    ShowMessage(result.data.ResponseType, result.data.Message)
                },
                function (error) {
                    console.log(error);
                });
            }
        },
        MoveSlotOutOfWip: function (slotNumber) {

            var self = this;
            this.$MoveOutOfWipService(slotNumber).then(function (result) {
                if (result.data.ResponseType == ResponseType.Success) {
                    KanbanTest.removeElement(slotNumber);
                }
                ShowMessage(result.data.ResponseType, result.data.Message)
            },
            function (error) {
                console.log(error);
            });
        },
        MoveToReadyToShip: function (slotNumber) {
            var self = this;
            this.$MoveToReadyToShipService(slotNumber).then(function (result) {
                if (result.data.ResponseType == ResponseType.Success) {
                    KanbanTest.removeElement(slotNumber);
                }
                ShowMessage(result.data.ResponseType, result.data.Message)
            },
            function (error) {
                console.log(error);
            });
        },
        MoveToShippedToSolarFacility: function (slotNumber) {
            var self = this;
            this.$MoveToAnotherSolarFacilityService(slotNumber).then(function (result) {
                if (result.data.ResponseType == ResponseType.Success) {
                    KanbanTest.removeElement(slotNumber);
                }
                ShowMessage(result.data.ResponseType, result.data.Message)
            },
            function (error) {
                console.log(error);
            });
        },
        ColorNumberOfItemsInBoardsTitle: function () {
            var totalOfItems = $('.kanban-title-board');
            for (var i = 0; i < totalOfItems.length; i++) {
                var innerText =  $('.kanban-title-board')[i].outerHTML;
                var startOfNumber = innerText.indexOf('(');
                var endOfNumber = innerText.indexOf(')');
                $('.kanban-title-board')[i].outerHTML = innerText.substring(0, startOfNumber - 1) +
                                                        ' <span>' +
                                                        innerText.substring(startOfNumber, endOfNumber) +
                                                        ')</span></div>';

                $('.kanban-title-board span').css("color", "#0a86e8");
            }
        },
        SetUserInformation: function () {
            var self = this;
            this.$GetUserInformationService()
           .then(function (resp) {
               if (resp.data.ResponseType == ResponseType.Success) {
                   self.userInformation = resp.data.Content;
               }
               else {
                   ShowMessage(resp.data.ResponseType, resp.data.Message)
               }
           },
           function (error) {
               console.log(error);
           });
        },
        EnableMoveItemsInKanban: function () {
            // Master Scheduler
            if (self.userInformation.RoleId != 1) {
                $(".kanban-item").css("pointer-events", "none");
            }
        }

    }
})