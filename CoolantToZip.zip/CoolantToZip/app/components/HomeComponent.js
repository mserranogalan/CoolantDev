Vue.use(HomeService);
Vue.use(Functions);

var clickTimer, lastRowCLickedId;

Vue.component('HomeComponent', {
    mixins: [masterComponent],
    components: {
        Multiselect: window.VueMultiselect.default,
        DxDataGrid: DxDataGrid,
        AccessoryDetails: AccessoryDetails,
        ossdetailscomponentTemplate: ossdetailscomponentTemplate
    },
    template: '#Home-Template',
    replace: true,
    data: function () {
        return {

            // START Master variables
            slotNumberSelected: '',
            isThereAnyPermissionOfEditability: false,
            slotViewSelected: {},
            slotsViews: [
                { ViewId: SlotViews.ProducLine, Description: 'Product Line' },
                { ViewId: SlotViews.ProductionPath, Description: 'Product Family' },
                { ViewId: SlotViews.ProductFamily, Description: 'Production Path Planned Exits' },
                { ViewId: SlotViews.UserQuery, Description: 'User defined Query' }
            ],
            shifts: ['0', '1', '2', '3'],
            productLine: '',
            mode: 'single',
            defaultLayout: [],
            slotDatesFormated: {
                originalPlanBuildStartDate: null,
                planBuildStart: null,
                actualTestStart: null,
                buildate: null,
                planTestStart: null,
                testdate: null,
                actualPlanPrepStart: null,
                planExitDate: null,
                commitShipDate: null,
                rstCommitDate: null,
                customerShipDate: null,
                customerNeedDate: null,
                planBuildStart: null,
                actualTestStart: null,
                planPrepStart: null,
                deliveryDate: null

            },
            mainSlotsStartDate: new Date(),
            mainSlotsEndDate: new Date(),
            familyDateStart: new Date(),
            familyEndStart: new Date(),
            currentDate: new Date(),
            productLineDateStart: new Date(),
            productLineDateEnd: new Date(),
            themeStyles: {
                header: {
                    color: '#fafafa',
                    backgroundColor: '#4a5867',
                    borderColor: '#404c59',
                    borderWidth: '1px 1px 0 1px',
                }
            },
            accesoryDetailsProperties: {
                ASlot: { Name: 'ASlot', Visible: false },
                Assy: { Name: 'Assy', Visible: false },
                BlDate: { Name: 'BlDate', Visible: false },
                TestDate: { Name: 'TestDate', Visible: false },
                DlvrDate: { Name: 'DlvrDate', Visible: false },
                SchgcDate: { Name: 'SchgcDate', Visible: false },
                CommitDate: { Name: 'CommitDate', Visible: false },
                CommitShipDate: { Name: 'CommitDate', Visible: false },
                GPSlot: { Name: 'GPSlot', Visible: false },
                So: { Name: 'So', Visible: false },
                Pn: { Name: 'Pn', Visible: false },
                SchGpn: { Name: 'SchGpn', Visible: false },
                Sn: { Name: 'Sn', Visible: false },
                CpromDt: { Name: 'CpromDt', Visible: false },
                Customer: { Name: 'Customer', Visible: false },
                CustProp: { Name: 'CustProp', Visible: false },
                Mo: { Name: 'Mo', Visible: false },
                CopsNo: { Name: 'CopsNo', Visible: false },
                Comments: { Name: 'Comments', Visible: false },
                Facility: { Name: 'Facility', Visible: false },
                SpnReq: { Name: 'SpnReq', Visible: false },
                ScDateReq: { Name: 'ScDateReq', Visible: false },
                Revenue: { Name: 'Revenue', Visible: false },
                RevenType: { Name: 'RevenType', Visible: false },
                RevenJunk: { Name: 'RevenJunk', Visible: false },
                Built: { Name: 'Built', Visible: false },
                DelvRd: { Name: 'DelvRd', Visible: false },
                AtpPool: { Name: 'AtpPool', Visible: false },
                Expr1: { Name: 'Expr1', Visible: false },
                OrdrStatus: { Name: 'OrdrStatus', Visible: false },
                SorecId: { Name: 'SorecId', Visible: false },
                InquiryNo: { Name: 'InquiryNo', Visible: false },
            },
            slotSelected: {
                ActualPlanPrepStart: null,
                ActualTestStart: null,
                BuildPitID: null,
                BuildPitDescription: null,
                BuildStatus: 0,
                Builddate: null,
                ChangedModel: null,
                Comments: null,
                CommitShipDate: null,
                Commitdate: null,
                Configuration: null,
                CustomerId: null,
                CustomerNeedDate: null,
                CustomerProperty: null,
                CustomerShipDate: null,
                DeliveryDate: null,
                DemandSourceId: null,
                DistrictCode: null,
                DomesticScope: null,
                Facility: null,
                Filler2: 0,
                Filler4: 0,
                InquiryNo: null,
                InternationalScope: null,
                IsBuilt: null,
                IsDelivered: null,
                IsDeliveryDateChanged: null,
                IsOPSChecked: null,
                IsPartNumberChanged: null,
                IsSOChecked: null,
                IsTested: null,
                ItWasReviewdTestDate: null,
                ItWasReviwedPrepDate: null,
                KanbanNo: null,
                MaterialOrderNo: null,
                Model: null,
                OSSStatusDesc: null,
                OrderBuildStatus: null,
                OrderStatus: null,
                OriginalPlanBuildStartDate: null,
                OriginalRTSCommitDate: null,
                PlanBuildCompleteShift: null,
                PlanBuildStart: null,
                PlanBuildStartShift: null,
                PlanExitDate: null,
                PlanPrepCompleteShift: null,
                PlanPrepStart: null,
                PlanPrepStartShift: null,
                PlanTestCompleteShift: null,
                PlanTestStart: null,
                PlanTestStartShift: null,
                Prepdate: null,
                ProductionBuildStatus: null,
                RSTCommitDate: null,
                RevisionHoldFlag: null,
                SerialNo: null,
                ServiceOrder: null,
                SlotNo: null,
                Testdate: null,
                RecommitReason: null,
                ChangedModelObject: null,
                FacilityObject: null,
                BuildPitObject: null,
                PlanBuildStartShift: null,
                PlanBuildCompleteShift: null,
                PlanTestStartShift: null,
                PlanTestCompleteShift: null,
                PlanPrepStartShift: null,
                PlanPrepCompleteShift: null
            },
            userInformation: [],
            slotPartNumbersList: [],
            alternateItemsList: [],
            lovAccessoryList: [],
            products: [
                        { ProductId: 2, Name: 'Saturn' },
                        { ProductId: 3, Name: 'CED Cat150' },
                        { ProductId: 4, Name: 'HED Cat150' },
                        { ProductId: 5, Name: 'CED T70/Titan' },
                        { ProductId: 1, Name: 'HED T70/Mars' },
                        { ProductId: 6, Name: 'HED Titan' },
                        { ProductId: 8, Name: 'Intl SubAssys' },
                        { ProductId: 9, Name: 'Field Repair' },
            ],
            criteriaList: [
                { criteriaId: 1, Description: 'Slot Number' },
                { criteriaId: 2, Description: 'Service Order Number' },
                { criteriaId: 3, Description: 'Serial Number' },
                { criteriaId: 4, Description: 'Inquiry Number' }
            ],
            criteriaSelected: {},
            criteriaQuery: '',
            productionFamiliesSelected: [],
            dateFieldSelected: {},
            productSelected: [],
            productLinesSelected: [],
            facilitiesSelected: [],
            // Move this to a viewModel and remove attributes, just keep the properties
            slotDetailsFromProperties: {
                OriginalPlanBuildStartDate: { Name: 'OriginalPlanBuildStartDate', Visible: false },
                PlanBuildStart: { Name: 'PlanBuildStart', Visible: false },
                ActualTestStart: { Name: 'ActualTestStart', Visible: false },
                Buildate: { Name: 'Buildate', Visible: false },
                PlanTestStart: { Name: 'PlanTestStart', Visible: false },
                Testdate: { Name: 'Testdate', Visible: false },
                ActualPlanPrepStart: { Name: 'ActualPlanPrepStart', Visible: false },
                PlanExitDate: { Name: 'PlanExitDate', Visible: false },
                Model: { Name: 'Model', Visible: false },
                CommitShipDate: { Name: 'CommitShipDate', Visible: false },
                Facility: { Name: 'Facility', Visible: false },
                RSTCommitDate: { Name: 'RSTCommitDate', Visible: false },
                CustomerShipDate: { Name: 'CustomerShipDate', Visible: false },
                SerialNo: { Name: 'SerialNo', Visible: false },
                CustomerId: { Name: 'CustomerId', Visible: false },
                InquiryNo: { Name: 'InquiryNo', Visible: false },
                ServiceOrder: { Name: 'ServiceOrder', Visible: false },
                MaterialOrderNo: { Name: 'MaterialOrderNo', Visible: false },
                CustomerNeedDate: { Name: 'CustomerNeedDate', Visible: false },
                DomesticScope: { Name: 'DomesticScope', Visible: false },
                InternationalScope: { Name: 'InternationalScope', Visible: false },
                Comments: { Name: 'Comments', Visible: false },
                CustomerProperty: { Name: 'CustomerProperty', Visible: false },
                filler4: { Name: 'filler4', Visible: false },
                OSSStatusDesc: { Name: 'OSSStatusDesc', Visible: false },
                IsBuilt: { Name: 'IsBuilt', Visible: false },
                IsTested: { Name: 'IsTested', Visible: false },
                IsDelivered: { Name: 'IsDelivered', visible: false },
                ItWasReviewdTestDate: { Name: 'ItWasReviewdTestDate', Visible: false },
                ItWasReviwedPrepDate: { Name: 'ItWasReviwedPrepDate', Visible: false },
                ChangedModel: { Name: 'ChangedModel', Visible: false },
                DistrictCode: { Name: 'DistrictCode', Visible: false },
                DeliveryDate: { Name: 'DeliveryDate', Visible: false },
                BuildPitID: { Name: 'BuildPitID', Visible: false },
                Prepdate: { Name: 'Prepdate', Visible: false },
                PlanPrepStart: { Name: 'PlanPrepStart', Visible: false },
                PlanBuildStartShift: { Name: 'PlanBuildStartShift', Visible: false },
                PlanBuildCompleteShift: { Name: 'PlanBuildCompleteShift', Visible: false },
                PlanTestStartShift: { Name: 'PlanTestStartShift', Visible: false },
                PlanTestCompleteShift: { Name: 'PlanTestCompleteShift', Visible: false },
                PlanPrepCompleteShift: { Name: 'PlanPrepCompleteShift', Visible: false },
                PlanPrepStartShift: { Name: 'PlanPrepStartShift', Visible: false },
            },
            // Filters
            inquiryNumber: "",
            itWasAcceptedReplaceSlottedPart: false,
            selectedDataGridRow: [],

            //DevExpressComponent
            allowColumnReordering: true,
            onOptionChanged: function (options) {
                var fullName = options.fullName;
                if (options.name == "columns") {

                    var index = fullName.substring(
                        fullName.lastIndexOf("[") + 1,
                        fullName.lastIndexOf("]")
                    );
                    app.slotsColumnsSettings[index].visibleIndex = options.value;
                    app.formId = 1;
                }
            },
            customizeColumns: function (columns) {

                if (columns != null && columns.length > 0)
                    this.defaultLayout = columns;

                var columnsStoredInDatabase = app.$children[0].userInformation.CustomLayout;

                if (columnsStoredInDatabase != null)
                    columnsStoredInDatabase = columnsStoredInDatabase.filter(
                        function (column) {
                            return column.formId == 1;
                        });

                if (columnsStoredInDatabase != null && columnsStoredInDatabase.length == columns.length)
                    for (var i = 0; i < columnsStoredInDatabase.length; i++) {
                        columns[i].visibleIndex = columnsStoredInDatabase[i].visibleIndex;
                        columns[i].visible = columnsStoredInDatabase[i].visible;
                    }

                app.slotsColumnsSettings = columns;
            },
            columnFixing: {
                enabled: true
            },
            columnChooser: {
                enabled: true,
                allowSearch: true,
                mode: "select"
            },
            rowExpanded: function(e){
                if (e.component.shouldSkipNext) {
                    e.component.shouldSkipNext = false;
                    return;
                }
                e.component.selectRows([e.key], false);
                e.component.collapseAll(-1);
                e.component.shouldSkipNext = true;
                e.component.expandRow(e.key);
                window.SlotNo = e.key;
                var detailGridInstance = $().dxDataGrid("instance");
                $.post(window.location.href + 'Accesories/GetLinkedAccesoriesByGPSlot', { gpSLOT: e.key }).done(function (result) {
                   window.linkedSlots =  result.Content;
                });
                //Vue.$emit('expandAccessories',e.key);
            },
            masterDetail: {
                enabled:true,
                template: //"linkedSlot"

                    function (container, options) {
                    var slotNumber = options.data.SlotNo;
                   var idPreloader = 'preLoad'+slotNumber;
                    container.append('<div id=' + idPreloader + ' class="preloader-wrapper active"><div class="spinner-layer spinner-red-only"><div class="circle-clipper left"><div class="circle"></div></div><div class="gap-patch"><div class="circle"></div></div><div class="circle-clipper right"><div class="circle"></div></div> </div></div>');

                    var slotLinkedAccessories = new Object();
                    $.post(Objects.path + '/Accesories/GetLinkedAccesoriesByGPSlot', { gpSLOT: slotNumber }).done(function (result) {
                        $('#' + idPreloader).hide();
                        slotLinkedAccessories = result.Content;

                        $("<div>")
                            .addClass("master-detail-caption")
                            .text(slotLinkedAccessories.length + " Linked Accessories:")
                            .appendTo(container);

                        $("<div>")
                            .dxDataGrid({
                                columnAutoWidth: true,
                                showBorders: true,
                                onCellClick: function (e) {
                                   
                                    if (clickTimer && lastRowCLickedId === e.rowIndex) {
                                        clearTimeout(clickTimer);
                                        clickTimer = null;
                                        lastRowCLickedId = e.rowIndex;

                                        var accessoryData = e.data;
                                        var gpSlot = accessoryData ? accessoryData.GPSlot : null;
                                        var itWasClickedAccessory = e.columnIndex > 0;

                                        $('#slots td:nth-child(n+3)').unbind();
                                        $('#slots td:nth-child(2)').unbind();
                                        $('.dx-datagrid-borders .dx-data-row td:nth-child(n+2)').unbind().dblclick(function ()
                                        {
                                            if (itWasClickedAccessory) {
                                                eventHub.$emit('refreshAccessoryInformation', accessoryData);
                                            }
                                        });
                                       
                                        $('.dx-datagrid-borders .dx-data-row td:nth-child(1)').unbind().dblclick(function () {
                                            if (e.columnIndex == 0 && gpSlot)
                                                app.$children[0].slotNumberSelected = gpSlot;
                                        });

                                    }
                                    else
                                    {
                                        clickTimer = setTimeout(function () {   
                                        }, 250);
                                    }

                                    lastRowCLickedId = e.rowIndex;
                                    e.event.stopPropagation();
                                   
                                },
                                columns: [
                                   {
                                       caption: 'Slot #',
                                       dataField: 'ASlot',
                                       width: 80
                                       
                                   },
                                   {
                                        dataField: "Assy.Abbreviation",
                                        caption: "Assy",
                                        width: 80
                                    },
                                    {
                                        dataField: "BlDate",
                                        caption:"Build Date",
                                        dataType: "date",
                                        width: 90
                                    },
                                    {
                                        caption: "Test Date",
                                        dataField: "TestDate",
                                        dataType: "date",
                                        width: 90
                                    },
                                    {
                                        caption: "Deliver Date",
                                        dataField: "DlvrDate",
                                        dataType: "date",
                                        width: 90
                                    },
                                    {
                                        caption: "Facility",
                                        dataField: "Facility",
                                        width: 80
                                    },
                                    {
                                        caption: "Old Commit",
                                        dataField: "SchgcDate",
                                        dataType: "date",
                                        width: 90
                                    },
                                    {
                                        caption: "Commit Ship",
                                        dataField: "CommitDate",
                                        dataType: "date",
                                        width: 90
                                    },
                                    {
                                        caption: "GPSlot",
                                        dataField: "GPSlot",
                                        width: 60
                                    },
                                    {
                                        caption: "SO#",
                                        dataField: "So",
                                        width: 130
                                    },
                                    {
                                        caption: "Model",
                                        dataField: "Pn",
                                        width: 130
                                    },
                                    {
                                        caption: "Chg. Model",
                                        dataField: "SchGpn",
                                        width: 130
                                    },
                                    {
                                        caption: "Serial #",
                                        dataField: "Sn",
                                        width: 130
                                    },
                                    {
                                        caption: "Customer",
                                        dataField: "Customer",
                                        width: 130
                                    },
                                    {
                                        dataField: "CustProp",
                                        caption: "Pro",
                                        dataType: "boolean",
                                        calculateCellValue: function (data) {
                                            if (data["CustProp"] === null) {
                                                return false;
                                            }

                                            return data["CustProp"];
                                        },
                                        width: 60
                                    },
                                    {
                                        caption: "MO#",
                                        dataField: "Mo",
                                        width: 130
                                    },
                                    {
                                        caption: "Comments",
                                        dataField: "Comments",
                                        width: 130
                                    },
                                    {
                                        caption: "Facility",
                                        dataField: "Facility",
                                        width: 80
                                    },
                                    {
                                        caption: "Order Status",
                                        dataField: "SorecId",
                                        width: 130
                                    },
                                    {
                                        caption: "Inquiry",
                                        dataField: "InquiryNo",
                                        width: 130
                                    },
                                    {
                                        caption: "Slot Type",
                                        dataField: "RevenType.WorkScopeDesc",
                                        width: 130
                                    },
                                    {
                                        dataField: "Built",
                                        caption: "Is Built",
                                        dataType: "boolean",
                                        calculateCellValue: function (data) {
                                            if (data["Built"] === null) {
                                                return false;
                                            }

                                            return data["Built"];
                                        },
                                        width: 100
                                    },
                                    {
                                        dataField: "DelvRd",
                                        caption: "Is Delivered",
                                        dataType: "boolean",
                                        calculateCellValue: function (data) {
                                            if (data["DelvRd"] === null) {
                                                return false;
                                            }

                                            return data["DelvRd"];
                                        },
                                        width: 100
                                    }
                                ],
                                dataSource: slotLinkedAccessories
                            }).attr("id", "detailGrid"+slotNumber).appendTo(container);

                    });                
                 
                }
            },
            columnAutoWidth: true,
            allowColumnResizing: true,
            filterRow: { visible: true },
            filterPanel: { visible: true },
            headerFilter: { visible: true },
            paginate: true,
            paging: { pageSize: 20 },
            selection: {
                mode: 'single'
            },
            height: function () {
                return window.innerHeight / 1.21;
            },
            onContentReady: function (e) {
                var visibleRowsCount = e.component.totalCount();

                var divWithCount = document.getElementById('totalRecordCount');

                if (divWithCount == null) {
                    divWithCount = document.createElement('div');
                    divWithCount.id = 'totalRecordCount';
                    divWithCount.classList = 'dx-datagrid-text-content';

                    if (typeof XPathResult === "undefined" || XPathResult === null) {

                    }
                    else {
                        var parentNode = document.evaluate('//*[@id="dataGrid"]/div/div[4]/div/div', document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;

                        parentNode.appendChild(divWithCount);
                    }

                }
                if (visibleRowsCount >= 0)
                    divWithCount.innerText = visibleRowsCount + (visibleRowsCount == 1 ? ' Record' : ' Records') + ' found'
                else
                    divWithCount.innerText = '';

            },
            contentReadyAction: function () {
                $("#gridContainer .dx-scrollable").dxScrollable({ showScrollbar: 'always' });
            },
            onCellPrepared: function (options) {

                if (options.column.dataField == "PlanBuildStart") {
                    var fieldData = options.displayValue;
                    var data = options.data;
                    var currentDate = new Date();
                    fieldHtml = options.text;
                    if (fieldData) {
                        if ((data.Builddate == null && formatDate(data.PlanBuildStart) < currentDate) || (data.Builddate != null && (formatDate(data.Builddate) > currentDate || formatDate(data.Builddate) > formatDate(data.PlanBuildStart)))) {
                            fieldHtml = options.text + "<span class='badge-red'></span>";
                        }
                        else {
                            fieldHtml = options.text + "<span class='badge-green'></span>";
                        }
                    }
                    options.cellElement.html(fieldHtml);
                }
                if (options.column.dataField == "ActualTestStart") {
                    var fieldData = options.displayValue;
                    var data = options.data;
                    var currentDate = new Date();
                    fieldHtml = options.text;
                    if (fieldData) {
                        if ((data.ActualTestStart != null && (formatDate(data.ActualTestStart) > currentDate || formatDate(data.ActualTestStart) > formatDate(data.PlanTestStart)))) {
                            fieldHtml = options.text + "<span class='badge-red'></span>";
                        }
                        else {
                            fieldHtml = options.text + "<span class='badge-green'></span>";
                        }
                    }
                    options.cellElement.html(fieldHtml);
                }
                if (options.column.dataField == "ActualTestStart") {
                    var fieldData = options.displayValue;
                    var data = options.data;
                    var currentDate = new Date();
                    fieldHtml = options.text;
                    if (fieldData) {
                        if ((data.ActualTestStart != null && (formatDate(data.ActualTestStart) > currentDate || formatDate(data.ActualTestStart) > formatDate(data.PlanTestStart)))) {
                            fieldHtml = options.text + "<span class='badge-red'></span>";
                        }
                        else {
                            fieldHtml = options.text + "<span class='badge-green'></span>";
                        }
                    }
                    options.cellElement.html(fieldHtml);
                }
                if (options.column.dataField == "DeliveryDate") {
                    var fieldData = options.displayValue;
                    var data = options.data;
                    var currentDate = new Date();
                    fieldHtml = options.text;
                    if (fieldData) {
                        if ((data.DeliveryDate != null && formatDate(data.DeliveryDate) > formatDate(data.PlanExitDate))) {
                            fieldHtml = options.text + "<span class='badge-red'></span>";
                        }
                        else {
                            fieldHtml = options.text + "<span class='badge-green'></span>";
                        }
                    }
                    options.cellElement.html(fieldHtml);
                }
                if (options.column.dataField == "InquiryNo") {
                    var fieldData = options.displayValue;
                    var data = options.data;
                    var currentDate = new Date();
                    fieldHtml = options.text;
                    if (options.rowType == 'data' && (!fieldData || !data.InquiryNo || !data.InquiryNo.length > 0)) {
                        fieldHtml = options.text + "<span class='badge-red'></span>";
                    }

                    options.cellElement.html(fieldHtml);

                    options.cellElement.attr('id', 'inquiry');
                }

                if (options.column.dataField == "SlotNo") {
                    options.cellElement.attr('id', 'slotNo');
                }
            },
            columns: [
                {
                    caption: 'Slot #',
                    dataField: 'SlotNo',
                    fixed: true,
                },
                {
                    caption: "Hold",
                    dataField: "RevisionHoldFlag",
                    dataType: "boolean",
                    calculateCellValue: function(data) {
                        if (data["RevisionHoldFlag"] === null) {
                            return false;
                        }
                
                        return data["RevisionHoldFlag"];
                    },
                },
                {
                    caption: "Build Rel",
                    dataField: "BuildRelease",
                    dataType: "boolean",
                    calculateCellValue: function (data) {
                        if (data["BuildRelease"] === null) {
                            return false;
                        }

                        return data["BuildRelease"];
                    }
                },
                  {
                      caption: "Build Pit",
                      dataField: "BuildPitDescription",
                  },
                {
                    caption: "Original Plan Build Start",
                    dataField: "OriginalPlanBuildStartDate",
                    dataType: "date",
                },
                {
                    caption: "Plan Build Start",
                    dataField: "PlanBuildStart",
                    dataType: "date",
                },
                {
                    caption: "Shift Start Bld Pln",
                    dataField: "PlanBuildStartShift",
                    dataType: "number",
                    width: 120,
                },

                {
                    caption: "Shift Compl Bld Pln",
                    dataField: "PlanBuildCompleteShift",
                    dataType: "number",
                    width: 120,
                },
                {
                    caption: "Actual Build Start",
                    dataField: "Builddate",
                    dataType: "date",
                },
                {
                    caption: "Plan Test Start",
                    dataField: "PlanTestStart",
                    dataType: "date",
                },

                {
                    caption: "Shift Start Tst Pln",
                    dataField: "PlanTestStartShift",
                    dataType: "number",
                    width: 120
                },
                 {
                     caption: "Shift Compl Tst Pln",
                     dataField: "PlanTestCompleteShift",
                     dataType: "number",
                     width: 120
                 },
                 {
                     caption: "Actual Test Start",
                     dataField: "ActualTestStart",
                     dataType: "date",
                 },
                 {
                     caption: "Plan Prep Start",
                     dataField: "PlanPrepStart",
                     dataType: "date",
                 },
                 {
                     caption: "Shift Start Prep Pln",
                     dataField: "PlanPrepStartShift",
                     dataType: "number",
                     width: 120
                 },
                  {
                      caption: "Shift Compl Prep Pln",
                      dataField: "PlanPrepCompleteShift",
                      dataType: "number",
                      width: 120
                  },
                 {
                     caption: "Actual Prep Start",
                     dataField: "ActualPlanPrepStart",
                     dataType: "date",
                 },
                  {
                      caption: "Plan Exit Date",
                      dataField: "PlanExitDate",
                      dataType: "date",
                  },
                   {
                       caption: "Actual Exit",
                       dataField: "DeliveryDate",
                       dataType: "date",
                   },
                   {
                       caption: "Model",
                       dataField: "Model",
                   },
                   {
                       caption: "Commit Ship",
                       dataField: "CommitShipDate",
                       dataType: "date",
                   },
                   {
                       caption: "Facility",
                       dataField: "Facility",
                   },
                   {
                       caption: "RTS Commit",
                       dataField: "RSTCommitDate",
                       dataType: "date",
                   },
                   {
                       caption: "Ship Date",
                       dataField: "CustomerShipDate",
                       dataType: "date",
                   },
                   {
                       caption: "Serial #",
                       dataField: "SerialNo",
                   },
                   {
                       caption: "Customer",
                       dataField: "CustomerId",
                   },
                   {
                       width: 140,
                       caption: "Inquiry",
                       dataField: "InquiryNo",
                   },
                   {
                       caption: "Service Order",
                       dataField: "ServiceOrder",
                   },
                   {
                       caption: "MO#",
                       dataField: "MaterialOrderNo",
                   },
                   {
                       caption: "Recommit Reason",
                       dataField: "RecommitReason.Description",
                   },
                    {
                        caption: "Customer Need Date",
                        dataField: "CustomerNeedDate",
                        dataType: "date",
                    },
                    {
                        caption: "Desoto Scope",
                        dataField: "DomesticScope",
                    },
                    {
                        caption: "International Scope",
                        dataField: "InternationalScope",
                    },
                    {
                        caption: "Comments",
                        dataField: "Comments",
                    },
                    {
                        caption: "Prop",
                        dataField: "CustomerProperty",
                    },
                    {
                        caption: "Order Status",
                        dataField: "OrderStatus",
                    },
                    {
                        caption: "OSS Status",
                        dataField: "OSSStatusDesc",
                    },
                    {
                        caption: "Build Status",
                        dataField: "OrderBuildStatus",
                    },
                    {
                        caption: "Is Built",
                        dataField: "IsBuilt",
                        dataType: "boolean",
                        calculateCellValue: function (data) {
                            if (data["IsBuilt"] === null) {
                                return false;
                            }

                            return data["IsBuilt"];
                        },
                    },
                    {
                        caption: "Is Tested",
                        dataField: "IsTested",
                        dataType: "boolean",
                        calculateCellValue: function (data) {
                            if (data["IsTested"] === null) {
                                return false;
                            }

                            return data["IsTested"];
                        },
                    },
                     {
                         caption: "Is Delivered",
                         dataField: "IsDelivered",
                         dataType: "boolean",
                         calculateCellValue: function (data) {
                             if (data["IsDelivered"] === null) {
                                 return false;
                             }

                             return data["IsDelivered"];
                         },
                     },
                     {
                         caption: "Test Def Reviewed",
                         dataField: "ItWasReviewdTestDate",
                         dataType: "boolean",
                         calculateCellValue: function (data) {
                             if (data["ItWasReviewdTestDate"] === null) {
                                 return false;
                             }

                             return data["ItWasReviewdTestDate"];
                         },
                     },
                     {
                         caption: "Preparation Date Reviewed",
                         dataField: "ItWasReviwedPrepDate",
                         dataType: "boolean",
                         calculateCellValue: function (data) {
                             if (data["ItWasReviwedPrepDate"] === null) {
                                 return false;
                             }

                             return data["ItWasReviwedPrepDate"];
                         },
                     },
                     {
                         caption: "Chg. Model",
                         dataField: "ChangedModel",
                     },
                     {
                         caption: "District",
                         dataField: "DistrictCode",
                     },
                     {
                         caption: "Original RTS",
                         dataField: "OriginalRTSCommitDate",
                         dataType: "date",
                     },
            ],
            rowDoubleClick: function (e) {
                var slotNo = e.key;
                window.SlotNo = slotNo;

                eventHub.$emit('setOSSGPSlot', slotNo, e.data.Model, e.data.InquiryNo);
                if (app.clickTimer && app.lastRowCLickedId === e.rowIndex) {
                    clearTimeout(app.clickTimer);
                    app.clickTimer = null;
                    app.lastRowCLickedId = e.rowIndex;
                    $('#slots td:nth-child(n+3)').unbind().dblclick(function () {
                        if (app.$children[0].isThereAnyPermissionOfEditability) {


                            var parameters = JSON.stringify({ "CriteriaId": 1, "CriteriaQuery": slotNo });
                            $.post(Objects.path + '/Home/GetScheduleQuery_Result', { parameters: parameters }).done(function (result) {

                                UpdateObjectBasedOnProperties(app.$children[0].selectedDataGridRow, result.data[0]);
                                $("#dataGrid").dxDataGrid("instance").refresh();
                                app.$children[0].UpdateSlotSelectedObjectProperties(app.$children[0].selectedDataGridRow);

                                $('#editSlotDetialsModal').modal('open');
                            });

                            var productLine = slotNo.substring(0, 1) == 'P' ? slotNo.substring(1, 1) : slotNo.substring(0, 1);

                            app.$children[0].slotPartNumbersList = 
                            app.$children[0].catalogs.PartNumbersList.filter(function (partNumber) {
                                return partNumber.ProductCode == productLine;
                            });                           
                        }
                    });
                    $('#slots td:nth-child(2)').unbind().dblclick(function (e) {
                        app.$children[0].slotNumberSelected = slotNo;
                    });
                } else {
                    app.clickTimer = setTimeout(function () { }, 250);
                    var grid = $("#dataGrid").dxDataGrid("instance");
                    app.$children[0].selectedDataGridRow = grid.getSelectedRowsData()[0];
                    app.$children[0].UpdateSlotSelectedObjectProperties(app.$children[0].selectedDataGridRow);
                }
                app.lastRowCLickedId = e.rowIndex;

               
            },
            // Approve changes form
            approveScheduleEnabled: false,
            gridDataSourceGPSlots: DevExpress.data.AspNet.createStore({
                key: 'SlotNo',
                loadUrl: Objects.path + '/Home/TestingDevExpress',
            }),
            remoteOperations: true
        }
    },
    created: function () {
        eventHub.$on('newGPSlotAdded', this.newGPSlotAdded);
        eventHub.$on('NonOSSAdded', this.NonOSSAdded);
        eventHub.$on('getRoleScheduleApprovePermission', this.GetRoleScheduleApprovePermission);
        eventHub.$on('setProductLine', this.setProductLine);
        this.productSelected = this.products[0];
        this.productLineDateStart = this.getMonthStartDate();
        this.mainSlotsStartDate = this.getMonthStartDate();
        this.familyDateStart = this.getMonthStartDate();

        this.productLineDateEnd = this.getMonthEndDate();
        this.mainSlotsEndDate = this.getMonthEndDate();
        this.familyEndStart = this.getMonthEndDate();
        this.GetUserInformation();
    },
    beforeDestroy: function () {
        eventHub.$off('newGPSlotAdded', this.newGPSlotAdded);
        eventHub.$off('NonOSSAdded', this.NonOSSAdded); 
        eventHub.$off('getRoleScheduleApprovePermission', this.GetRoleScheduleApprovePermission);
        eventHub.$off('setProductLine', this.setProductLine);
    },
    mounted: function () {
        self = this;      
        mountElements();

        // Starts Materialize initialization

        $("#productLineModal").on("click", function (event) {
            $('#productionLineFiltersModal').modal('open');
        });
        $("#productFamilyModal").on("click", function (event) {
            $('#productionFamilyFiltersModal').modal('open');
        });
        $("#productPathModal").on("click", function (event) {
            $('#productionPathsFiltersModal').modal('open');
        });
        var config = {
            forceIsoDateParsing: true
        };
        DevExpress.config(config);

    },
    updated: function () {
        var self = this;
    },
    methods: {
        // Move this two methods to master
        getMonthStartDate: function(){

            return new Date( (this.currentDate.getFullYear()), (this.currentDate.getMonth()), 1);
        },
        getMonthEndDate: function () {
            return new Date((this.currentDate.getFullYear()), (this.currentDate.getMonth() + 1), 0);
        },
        CreateStore: function (parameters, url) {

            self.gridDataSourceGPSlots = DevExpress.data.AspNet.createStore({
                key: 'SlotNo',
                loadUrl: Objects.path + url,
                loadParams: {
                    'parameters':parameters
                }
            });
        },
        ChangeSlotView: function (viewId) {
            var self = this;
            switch (viewId) {
                case SlotViews.ProducLine:
                    $('#productionLineFiltersModal').modal({dismissible:false})
                    $('#productionLineFiltersModal').modal('open');
                    break;
                case SlotViews.ProductionPath:
                    $('#productionFamilyFiltersModal').modal({ dismissible: false });
                    $('#productionFamilyFiltersModal').modal('open');
                    break;
                case SlotViews.ProductFamily:
                    $('#productionPathsFiltersModal').modal({ dismissible: false });
                    $('#productionPathsFiltersModal').modal('open');
                    break;
                case SlotViews.UserQuery:
                    $('#queryFiltersModal').modal({ dismissible: false });
                    $('#queryFiltersModal').modal('open');
                    break;
                default:
                    break;
            }
           
        },
        moment: function () {
            return moment();
        },
        getSelectedFacilityFamily: function () {
            var facilityHtml = '', familyHtml = '';

            if (this.facilitiesSelected.length > 5)
                facilityHtml = ' <b class="tooltipped" data-position="bottom" data-tooltip="' + this.getSelectedFacilities() + '">Multiple Facilities Selected</b>, ';
            else
                facilityHtml = this.getSelectedFacilities();

            if (this.productLinesSelected.length > 4)
                familyHtml = ' <b class="tooltipped" data-position="bottom" data-tooltip="' + this.getSelectedProductLines() + '">Multiple Products Selected</b> ';
            else
                familyHtml = this.getSelectedProductLines();
            return facilityHtml +familyHtml;

        },
        getSelectedFacilities: function () {

            var outputHtml = ' <b> Selected Facilit' + (this.facilitiesSelected.length > 1 ? 'ies' : 'y') + ': </b> ';

            for (var i = 0; i < this.facilitiesSelected.length; i++)
                {
                outputHtml = outputHtml + this.facilitiesSelected[i].Descrioption;

                if (i < this.facilitiesSelected.length - 1)
                    outputHtml = outputHtml  + ', ';
                }
            return outputHtml;

        },        
        getSelectedProductLines: function () {
            var outputHtml = ' <b>Selected Products: </b> ';

            for (var i = 0; i < this.productLinesSelected.length; i++) {
                outputHtml = outputHtml + this.productLinesSelected[i].Description;

                if (i < this.productLinesSelected.length - 1)
                    outputHtml = outputHtml + ', ';
            }
            return outputHtml;
        },
        getSelectedFamilies: function () {
            var outputHtml = ' <b>Selected Families: </b> ';
            
            for (var i = 0; i < this.productionFamiliesSelected.length; i++)
            {
                outputHtml = outputHtml + this.productionFamiliesSelected[i].Description;

                if (i < this.productionFamiliesSelected.length -1)
                    outputHtml = outputHtml  + ', ';
            }
            return outputHtml;
        },
        getCurrentFilter: function () {           
           
            if (this.slotViewSelected != null && this.slotViewSelected.ViewId != null) {
            switch (this.slotViewSelected.ViewId) {
                
                case 1: // Production line
                    return (this.dateFieldSelected.Name != null ? '<b>Date field:</b> ' + this.dateFieldSelected.Name : '') + ' <b>From:</b> ' + moment(this.productLineDateStart).format('MM/DD/YYYY') + ' <b>To:</b> ' + moment(this.productLineDateEnd).format('MM/DD/YYYY') + this.getSelectedFacilityFamily();
                   
                case 2: // Production family
                    return (this.dateFieldSelected.Name != null ? '<b>Date field:</b> ' + this.dateFieldSelected.Name : '') + ' <b>From:</b> ' + moment(this.familyDateStart).format('MM/DD/YYYY') + ' <b>To:</b> ' + moment(this.familyEndStart).format('MM/DD/YYYY') + this.getSelectedFamilies();
                    
                case 3: // Production Path
                    return '<b>Path:</b> ' + this.productSelected.Name + ' <b>From:</b> ' + moment(this.mainSlotsStartDate).format('MM/DD/YYYY') + ' <b>To:</b> ' + moment(this.mainSlotsEndDate).format('MM/DD/YYYY');
                   
                   
                case SlotViews.UserQuery:
                    return (this.criteriaSelected.Description != null ?  ' <b>Criteria:</b> ' + this.criteriaSelected.Description : '') +  (this.criteriaQuery != null && this.criteriaQuery.length >0 ?( ' <b>Term:</b> ' + this.criteriaQuery) : '');
                  
                   
                default:
                    return '';
            }
           
            } else
                return '';
           
        },
        clearFilters: function(){
            this.slotViewSelected = {};
            this.gridDataSourceGPSlots = {};
            this.criteriaQuery = '';
            this.criteriaSelected = {};
            $('.tooltipped').tooltip('remove');
            self.CreateStore(null, '/Home/TestingDevExpress');
        },
        AddToCashList: function () {
            
            var self = this;
            this.$AddToCashListService(self.slotSelected.SlotNo)
           .then(function (result) {
               ShowMessage(result.data.ResponseType, result.data.Message)
           },
           function (error) {
               console.log(error);
           });
        },
        GetRoleScheduleApprovePermission: function (approveScheduleEnabled) {
            var self = this;
            self.approveScheduleEnabled = approveScheduleEnabled;
        },
        setProductLine: function(productLine){
            this.productLine = productLine;
        },
        newGPSlotAdded: function (slotNumber) {
            var self = this;
            self.GetSlotBySlotNumber(slotNumber);
        },
        // The v-calendar requires the correct format to binding/display dates
        formatDate: function (date) {

            if (!date) {
                return null;
            }
            else {
                return new Date(date);
            }
        },

        // VIEW: Production Path Planned Exists
        GetSlotsSchedule: function (filter) {
            var self = this;

            var parameters = JSON.stringify({
                dateField: null,
                dateStart: ValidateChangeInDateAndAddItOffset(this.mainSlotsStartDate),
                dateEnd: ValidateChangeInDateAndAddItOffset(this.mainSlotsEndDate),
                DefaultSort: 'PlanBuildStart',
                productionPath: this.productSelected.Name,
                productionPathList: [{ ProductFamilyId: this.productSelected.ProductId, Description: this.productSelected.Name }],
                facilityCodes: null
            });
            self.CreateStore(parameters, '/Home/GetProductionPathScheduleQuery');

            $("#productionPathsFiltersModal").modal('close');
            $('.tooltipped').tooltip({ html: true });
        },
        // VIEW: Production Family Filter 
        GetPMSlotsSchedule: function (filter) {
            var self = this;
            var parameters = JSON.stringify({
                dateField: self.dateFieldSelected.SchemaName,
                defaultSort: self.dateFieldSelected.TextToDisplay,
                dateStart: ValidateChangeInDateAndAddItOffset(this.familyDateStart),
                dateEnd: ValidateChangeInDateAndAddItOffset(this.familyEndStart),
                productionPathList: self.productionFamiliesSelected,
                facilityCodes: null
            });
            self.CreateStore(parameters, '/Home/GetPMProductionGroupScheduleQuery');
            $("#productionFamilyFiltersModal").modal('close');
            $('.tooltipped').tooltip({ html: true });
        },
        // VIEW: Production Line Filter
        GetNewPMScheduleQuery: function (filter) {
            var self = this;

            var parameters = JSON.stringify({
                dateField: self.dateFieldSelected.SchemaName,
                defaultSort: self.dateFieldSelected.TextToDisplay,
                dateStart: ValidateChangeInDateAndAddItOffset(this.productLineDateStart),
                dateEnd: ValidateChangeInDateAndAddItOffset(this.productLineDateEnd),
                productionLinesList: self.productLinesSelected,
                facilityCodesList: self.facilitiesSelected
            });
           
            self.CreateStore(parameters, '/Home/GetNewPMScheduleQuery_Result');
            $("#productionLineFiltersModal").modal('close');
            $('.tooltipped').tooltip({ html: true });
        },
        GetScheduleQuery: function (filter) {
            var self = this;

            var parameters = JSON.stringify({CriteriaId: this.criteriaSelected.criteriaId, CriteriaQuery: this.criteriaQuery });

            self.CreateStore(parameters, '/Home/GetScheduleQuery_Result');
            $("#queryFiltersModal").modal('close');
            $('.tooltipped').tooltip({ html: true });
        },
        
        // Slot selected from slots table
        UpdateSlotSelectedObjectProperties: function (slot) {            
            var self = this;
            if (slot == null)
                return;
            UpdateObjectBasedOnProperties(self.slotSelected, slot);
            self.FormatDatesOfSlotSelected(slot);
        },
        FormatDatesOfSlotSelected: function (slot) {
            var self = this;

            self.slotDatesFormated.originalPlanBuildStartDate = formatDate(slot.OriginalPlanBuildStartDate);
            self.slotDatesFormated.buildate =                   formatDate(slot.Builddate);
            self.slotDatesFormated.planTestStart =              formatDate(slot.PlanTestStart);
            self.slotDatesFormated.testdate =                   formatDate(slot.Testdate);
            self.slotDatesFormated.actualPlanPrepStart =        formatDate(slot.ActualPlanPrepStart);
            self.slotDatesFormated.planExitDate =               formatDate(slot.PlanExitDate);
            self.slotDatesFormated.commitShipDate =             formatDate(slot.CommitShipDate);
            self.slotDatesFormated.rstCommitDate =              formatDate(slot.RSTCommitDate);
            self.slotDatesFormated.customerShipDate =           formatDate(slot.CustomerShipDate);
            self.slotDatesFormated.customerNeedDate =           formatDate(slot.CustomerNeedDate);
            self.slotDatesFormated.planBuildStart =             formatDate(slot.PlanBuildStart);
            self.slotDatesFormated.actualTestStart =            formatDate(slot.ActualTestStart);
            self.slotDatesFormated.planPrepStart =              formatDate(slot.PlanPrepStart);
            self.slotDatesFormated.deliveryDate =               formatDate(slot.DeliveryDate);

        },
       
        // Update GP Slot basic details
        UpdateGPSlot: function () {
            var self = this;
            var IsThereAnyValidation = false;

            self.UpdateDatesInSlot();
            this.$UpdateGPSlotService(self.slotSelected).then(function (resp) {
                // NOTE: Please pull all the validatino results in a method
                for (var i = 0; i < resp.data.length; i++) {
                    if (resp.data[i].ResponseType != ResponseType.Success) {

                        ShowMessage(resp.data[i].ResponseType, resp.data[i].Message)
                        IsThereAnyValidation = true;
                    }
                }
                if (!IsThereAnyValidation) {

                    ShowMessage(resp.data[0].ResponseType, resp.data[0].Message);
                    // Maybe I need to change this to just update looking for the slot number in the original list

                    if (self.userInformation.RoleId == 2 && self.slotSelected.InquiryNo != null && self.slotSelected.InquiryNo.length >0){
                        ShowMessage(resp.data[0].ResponseType, 'Sending data to CRM..');
                        self.$UpdateGPSlotServiceCRM(self.slotSelected.InquiryNo).then(function (resp) {

                            ShowMessage(resp.data.ResponseType, resp.data.Message);

                        }, function (error) {


                        });

                    }

                    //should I use self.dataGridItems ? 
                    UpdateObjectBasedOnProperties(self.selectedDataGridRow, resp.data[0].Content);
                    $("#dataGrid").dxDataGrid("instance").refresh();
                }


            }, function (error) {
                console.log(error);
            });
        },

        // Update dates in slotSelected before proceed to send to backend and save
        UpdateDatesInSlot: function () {

            var self = this;
            self.slotSelected.OriginalPlanBuildStartDate = ValidateChangeInDateAndAddItOffset(self.slotDatesFormated.originalPlanBuildStartDate);
            self.slotSelected.Builddate =           ValidateChangeInDateAndAddItOffset(self.slotDatesFormated.buildate);
            self.slotSelected.PlanTestStart =       ValidateChangeInDateAndAddItOffset(self.slotDatesFormated.planTestStart);
            self.slotSelected.Testdate =            ValidateChangeInDateAndAddItOffset(self.slotDatesFormated.testdate);
            self.slotSelected.ActualPlanPrepStart = ValidateChangeInDateAndAddItOffset(self.slotDatesFormated.actualPlanPrepStart);
            self.slotSelected.PlanExitDate =        ValidateChangeInDateAndAddItOffset(self.slotDatesFormated.planExitDate);
            self.slotSelected.CommitShipDate =      ValidateChangeInDateAndAddItOffset(self.slotDatesFormated.commitShipDate);
            self.slotSelected.RSTCommitDate =       ValidateChangeInDateAndAddItOffset(self.slotDatesFormated.rstCommitDate);
            self.slotSelected.CustomerShipDate =    ValidateChangeInDateAndAddItOffset(self.slotDatesFormated.customerShipDate);
            self.slotSelected.CustomerNeedDate =    ValidateChangeInDateAndAddItOffset(self.slotDatesFormated.customerNeedDate);
            self.slotSelected.PlanBuildStart =      ValidateChangeInDateAndAddItOffset(self.slotDatesFormated.planBuildStart);
            self.slotSelected.ActualTestStart =     ValidateChangeInDateAndAddItOffset(self.slotDatesFormated.actualTestStart);
            self.slotSelected.PlanPrepStart =       ValidateChangeInDateAndAddItOffset(self.slotDatesFormated.planPrepStart);
            self.slotSelected.DeliveryDate =        ValidateChangeInDateAndAddItOffset(self.slotDatesFormated.deliveryDate);
        },
        GetLinkedAccesoriesByGPSlot: function (gpSlot) {            

            this.$getLinkedAccesoriesByGPSlot(gpSlot).then(function (resp) {
                if (resp.data.ResponseType != ResponseType.Success) {

                    console.log(resp.data);
                }
                else {
                    console.log('error');
                }
            }, function (error) {
                console.log(error);
            });
        },
        GetSlotBySlotNumber: function (slotNo) {
            var self = this;

            this.$GetSlotBySlotNumber(slotNo).then(function (resp) {
                if (resp.data.ResponseType != ResponseType.Success) {

                    ShowMessage(resp.data.ResponseType, resp.data.Message);
                }
                else {
                    //should I use self.dataGridItems ? 

                    var grid = $('#dataGrid').dxDataGrid('instance');
                    grid.getDataSource().items().push(resp.data.Content);
                    grid.refresh();
                    var message = "Content updated"
                    ShowMessage(resp.data.ResponseType, message);
                }
            }, function (error) {
                console.log(error);
            });
        },
        AddSlot: function () {
            if (this.productLine == null || this.productLine == "") {
                ShowMessage(ResponseType.Validation, 'You must first set your Preferences.  Click on Actions, then Preferences.');
            }
            else {

                eventHub.$emit('refreshSlot', 1, this.productLine);
                $('#addSlotComponent').modal();
                $('#addSlotComponent').modal('open');
            }
        },
        RemoveInquiryNumber: function () {
            var self = this;

            this.$RemoveInquiryNumberService(self.slotSelected)
           .then(function (resp) {

               var tempInquiryNumber = self.slotSelected.InquiryNo;
               if (resp.data.ResponseType == ResponseType.Success) {
                   var content = resp.data.Content;

                   if (tempInquiryNumber && tempInquiryNumber != "") {
                       self.SendProductionDataToCRM(self.slotSelected);
                   }

                   self.slotSelected.InquiryNo = "";

                   UpdateObjectBasedOnProperties(self.selectedDataGridRow, self.slotSelected);
                   $("#dataGrid").dxDataGrid("instance").refresh()
               }
               ShowMessage(resp.data.ResponseType, resp.data.Message);


           }, function (error) { console.log(error); });
        },
        ResetColumns: function () {
            this.ResetLayout(1);

            var grid = $('#dataGrid').dxDataGrid('instance');
            var columns = grid.option("columns");
            grid.beginUpdate();
            for (var i = 0; i < columns.length; i++) {
                var isDefaltColumn = this.defaultLayout.indexOf(columns[i].dataField) != -1;
                grid.columnOption(columns[i].dataField, "visible", 1);
            }
            grid.endUpdate();
        },
    },
    computed: {
    }
})
const app = new Vue({
    el: '#app',
    data: {
        pagination: {
            current: 1,
            total: 0,
            itemsPerPage: 10
        },
        test1: 200,
        value: 'Orig Value 1'
    },
    methods: {
        Paged: function (page) {
            var self = this;
            console.log('current: ' + page)
        },
        changeValue: function () {
            this.value = 'ABC';
        }
    }
});

