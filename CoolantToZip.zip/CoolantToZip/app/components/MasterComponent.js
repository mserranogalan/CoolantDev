﻿Vue.use(MasterService);
Vue.use(ScheduleService);

var masterComponent = Vue.component('masterComponent', {
    //el: '#masterApp',
    data: function () {
        return {
            catalogs: {
                AccesoryTypesList: [],
                AlternateItemsList: [],
                BuildPitList: [],
                DateFieldsList: [],
                FacilityList: [],
                LovAccessoryList: [],
                OOsStatusList: [],
                OrderStatusList: [],
                PartNumbersList: [],
                ProductFamiliesList: [],
                ProductLinesList: [],
                ProductList: [],
                ProductionStates: [],
                RecommitReasonList: [],
                WipLocationsList: [],
                WorkScopeList: [],

            },
            offsetInHoursPSTVsLocalTime: 0,
            productLine: 'S',
            roleId: 0,
            approveScheduleEnabled: false,
            userInformation: [],
            slotScheduleApprovalsNumber: 1,
            accesoryScheduleApprovalsNumber: 1,
            clickTimer: '',
            lastRowCLickedId: '',
            dismissSlottedPartValidation: false,
            slotsColumnsSettings: {},
            formId: null,

            accesoriesDatesFormatted: {
                BlDate: null,
                TestDate: null,
                TestDate: null,
                SchgcDate: null,
                CommitDate: null,
                DlvrDate: null
            },
            //accesoriesColumnsSettings: {},
            slotSelected: {
                ActualPlanPrepStart: null,
                ActualTestStart: null,
                BuildPitID: null,
                BuildPitDescription: null,
                BuildStatus: 0,
                Builddate: null,
                ChangedModel: null,
                Comments: null,
                CommitShipDate: null,
                Commitdate: null,
                Configuration: null,
                CustomerId: null,
                CustomerNeedDate: null,
                CustomerProperty: null,
                CustomerShipDate: null,
                DeliveryDate: null,
                DemandSourceId: null,
                DistrictCode: null,
                DomesticScope: null,
                Facility: null,
                Filler2: 0,
                Filler4: 0,
                InquiryNo: null,
                InternationalScope: null,
                IsBuilt: null,
                IsDelivered: null,
                IsDeliveryDateChanged: null,
                IsOPSChecked: null,
                IsPartNumberChanged: null,
                IsSOChecked: null,
                IsTested: null,
                ItWasReviewdTestDate: null,
                ItWasReviwedPrepDate: null,
                KanbanNo: null,
                MaterialOrderNo: null,
                Model: null,
                OSSStatusDesc: null,
                OrderBuildStatus: null,
                OrderStatus: null,
                OriginalPlanBuildStartDate: null,
                OriginalRTSCommitDate: null,
                PlanBuildCompleteShift: null,
                PlanBuildStart: null,
                PlanBuildStartShift: null,
                PlanExitDate: null,
                PlanPrepCompleteShift: null,
                PlanPrepStart: null,
                PlanPrepStartShift: null,
                PlanTestCompleteShift: null,
                PlanTestStart: null,
                PlanTestStartShift: null,
                Prepdate: null,
                ProductionBuildStatus: null,
                RSTCommitDate: null,
                RevisionHoldFlag: null,
                SerialNo: null,
                ServiceOrder: null,
                SlotNo: null,
                Testdate: null

            },
            accesoryDetailsProperties: {
                ASlot: { Name: 'ASlot', Visible: false },
                Assy: { Name: 'Assy', Visible: false },
                BlDate: { Name: 'BlDate', Visible: false },
                TestDate: { Name: 'TestDate', Visible: false },
                DlvrDate: { Name: 'DlvrDate', Visible: false },
                SchgcDate: { Name: 'SchgcDate', Visible: false },
                CommitDate: { Name: 'CommitDate', Visible: false },
                CommitShipDate: { Name: 'CommitDate', Visible: false },
                GPSlot: { Name: 'GPSlot', Visible: false },
                So: { Name: 'So', Visible: false },
                Pn: { Name: 'Pn', Visible: false },
                SchGpn: { Name: 'SchGpn', Visible: false },
                Sn: { Name: 'Sn', Visible: false },
                CpromDt: { Name: 'CpromDt', Visible: false },
                Customer: { Name: 'Customer', Visible: false },
                CustProp: { Name: 'CustProp', Visible: false },
                Mo: { Name: 'Mo', Visible: false },
                CopsNo: { Name: 'CopsNo', Visible: false },
                Comments: { Name: 'Comments', Visible: false },
                Facility: { Name: 'Facility', Visible: false },
                SpnReq: { Name: 'SpnReq', Visible: false },
                ScDateReq: { Name: 'ScDateReq', Visible: false },
                Revenue: { Name: 'Revenue', Visible: false },
                RevenType: { Name: 'RevenType', Visible: false },
                RevenJunk: { Name: 'RevenJunk', Visible: false },
                Built: { Name: 'Built', Visible: false },
                DelvRd: { Name: 'DelvRd', Visible: false },
                AtpPool: { Name: 'AtpPool', Visible: false },
                Expr1: { Name: 'Expr1', Visible: false },
                OrdrStatus: { Name: 'OrdrStatus', Visible: false },
                SorecId: { Name: 'SorecId', Visible: false },
                InquiryNo: { Name: 'InquiryNo', Visible: false },
            },

            accesorySelected: {
                ASlot: "",
                Assy: null,
                BlDate: "",
                TestDate: "",
                DlvrDate: "",
                SchgcDate: "",
                CommitDate: "",
                GPSlot: "",
                So: "",
                Pn: "",
                SchGpn: "",
                Sn: "",
                CpromDt: "",
                Customer: "",
                CustProp: false,
                Mo: "",
                CopsNo: "",
                Comments: "",
                Facility: "",
                SpnReq: false,
                ScDateReq: false,
                Revenue: false,
                RevenType: null,
                RevenJunk: "",
                Built: false,
                DelvRd: false,
                AtpPool: false,
                Expr1: false,
                OrdrStatus: false,
                SorecId: "",
                InquiryNo: "",
                ModelObject: null,
                FacilityObject: null,
                ChangedModelObject: null,
                IsPartNumberChanged: false
            },
            accessoryFormFieldAccess: {},
            layout: [],
            parentCounter: 0,
        }
    },
    created: function () {
        var self = this;
        self.offsetInHoursPSTVsLocalTime = GetDifferenceInHoursOfUTCTimeVsCurrentLocationTime();

        eventHub.$on('refreshAccessoryInformation', this.refreshAccessoryInformation);
        eventHub.$on('selectedAccessory', this.selectedAccessory);
        eventHub.$on('checkScheduleChanges', self.checkScheduleChanges);
        eventHub.$on('newGPSlotAdded', self.newGPSlotAdded);
        eventHub.$on('updateProductLine', self.updateProductLine)
    },
    beforeDestroy: function () {
        eventHub.$off('refreshAccessoryInformation', this.refreshAccessoryInformation);
        eventHub.$off('selectedAccessory', this.selectedAccessory);
        eventHub.$off('checkScheduleChanges', this.checkScheduleChanges);
        eventHub.$off('updateProductLine', this.updateProductLine)
    },
    mounted: function () {

    },
    updated: function () {

    },
    methods: {
        GetMonthStartDate: function () {

            return new Date((this.currentDate.getFullYear()), (this.currentDate.getMonth()), 1);
        },
        GetMonthEndDate: function () {
            return new Date((this.currentDate.getFullYear()), (this.currentDate.getMonth() + 1), 0);
        },
        setPreferences: function () {
            eventHub.$emit('setProductLine', this.productLine);
            $('#preferencesComponent').modal();
            $('#preferencesComponent').modal('open');
        },
        updateProductLine: function (ProductLine) {
            var self = this;
            this.$UpdateUserPreference(ProductLine).then(function (resp) {
                if (resp.data.ResponseType != ResponseType.Success) {

                    ShowMessage(resp.data.ResponseType, resp.data.Message);
                }
                else {
                    self.$nextTick(function () { self.productLine = ProductLine; });
                    ShowMessage(resp.data.ResponseType, resp.data.Message);
                }
                eventHub.$emit('setProductLine', ProductLine);
            }, function (error) {
                //Materialize.toast('There was an error registering your checkin, contact your supervisor.' + error, 4000, 'error');
                console.log(error);
            });
        },
        openApprovals: function () {
            eventHub.$emit('setScheduleProductLine', self.productLine);
            self.approveScheduleEnabled && $('#ScheduleApproveModal').modal({
                dismissible: true, complete: function () {
                    Cookies.set('approvalDismissed', 'true');
                }
            });
            self.approveScheduleEnabled && $('#ScheduleApproveModal').modal('open');

            setTimeout(function () {

                $('#dataGridApprovals').show();
                $('#dataAccesoryGridApprovals').hide();
                $('#accesoriesMastSched').hide();
                $('#gasProducerTab').click();
            }, 1500)
        },
        approvalsDismissed: function () {
            var cookie = Cookies.get("approvalDismissed");
            if (cookie) {
                //console.log('already viewed the approvals');
                return true;
            }
            else
                return false;

        },
        checkScheduleChanges: function (source) {
            if (source == 2)
                console.log("auto approval modal");
            else
                console.log("manual click approval");

            var self = this;
            setTimeout(function () {

                if (self.approveScheduleEnabled && (source == 1 || !self.approvalsDismissed())) {

                    //self.approveScheduleEnabled = (self.slotScheduleApprovalsNumber > 0 || self.accesoryScheduleApprovalsNumber > 0);
                    if (self.userInformation.RoleId == 2)
                        self.$PMNotificationsExist(self.userInformation.Preference).then(function (resp) {
                            if (resp.data.ResponseType == ResponseType.Success && resp.data.Content)
                                self.openApprovals();
                            else
                                ShowMessage(4, 'There are no pending approvals');

                        }, function (error) {
                            console.log(error);
                        });
                    else
                        self.$OPSNotificationsExist(self.userInformation.Valuestreams).then(function (resp) {
                            if (resp.data.ResponseType == ResponseType.Success && resp.data.Content)
                                self.openApprovals();
                            else
                                ShowMessage(4, 'There are no pending approvals');
                        }, function (error) {
                            console.log(error);
                        });
                }

            }, 500);

        },
        getInquiriesList: function () {

            eventHub.$emit('getInquiriesList', this.productLine);

            $('#InquiriesModal').modal();
            $('#InquiriesModal').modal('open');
        },
        addSlot: function (type) {

            eventHub.$emit('refreshSlot', type, this.productLine);

            //if (addSlotComponent != null)
            //    addSlotComponent._data.type = type;

            $('#addSlotComponent').modal();
            $('#addSlotComponent').modal('open');
        },
        searchSlot: function (type) {
            eventHub.$emit('setSearchType', type);

            $('#searchSlotComponent').modal();
            $('#searchSlotComponent').modal('open');

        },
        checkRoleScheduleApprovePermission: function () {
            if (this.userInformation != null) {
                var role = this.userInformation.RoleId;
                switch (role) {
                    case 1:
                        if (this.userInformation.Valuestreams.length > 0) {
                            this.approveScheduleEnabled = true;
                        }
                        break;
                    case 2:
                        this.approveScheduleEnabled = true;
                        break;

                }

                if (this.approveScheduleEnabled)
                    this.GetPendingApprovalSlots();

                eventHub.$emit('getRoleScheduleApprovePermission', this.approveScheduleEnabled);
            }
        },
        GetPendingApprovalSlots: function () {
            this.checkScheduleChanges(2);
        },
        GetUserInformation: function () {
            var self = this;
            this.$GetUserInformationService()
           .then(function (resp) {

               if (resp.data.ResponseType == ResponseType.Success) {
                   var content = resp.data.Content;
                   self.userInformation = content;
                   self.productLine = self.userInformation.Preference;
                   self.productLine = content.Preference;


                   self.GetEssentialInformationService();
                   self.EnableInquiriesFunction();
                   self.EnableCashList();

                   self.checkRoleScheduleApprovePermission();
                   self.roleId = content.RoleId;
               }
               else {
                   ShowMessage(resp.data.ResponseType, resp.data.Message)
               }
           },
           function (error) {
               console.log(error);
           });
        },
        GetEssentialInformationService: function () {
            var self = this;
            this.$getEssentialInformationService(self.offsetInHoursPSTVsLocalTime)
           .then(function (resp) {
               if (resp.data.ResponseType == ResponseType.Success) {
                   var content = resp.data.Content;

                   self.accessoryFormFieldAccess = content.UserInformation.FormFieldAccess;
                   self.catalogs = resp.data.Content.Catalogs;
                   self.dateFieldSelected = self.catalogs.DateFieldsList[3];

                   // Plase separete permissions, static ? 
                   // it content comes from current call
                   var slotPermissions = false;
                   var accyPermissions = DisplayFields(self.accesoryDetailsProperties, content.UserInformation.FormFieldAccess);
                   // self.userinformation comes from the other previous call, GetUserInformation
                   if (self.slotDetailsFromProperties != null) {
                       slotPermissions = DisplayFields(self.slotDetailsFromProperties, self.userInformation.FormFieldAccess);
                   }
                   self.isThereAnyPermissionOfEditability = accyPermissions || slotPermissions;


                   $("#userRole").text(self.userInformation.RoleName);
               }
               else {
                   ShowMessage(resp.data.ResponseType, resp.data.Message)
               }
           },
           function (error) {
               console.log(error);
           });
        },


        LinkInquiryNumberToGpSlot: function (inquiryNo, slotSelected) {
            var self = this;
            self.inquiryNumber = inquiryNo;

            self.GetSlotInquiryGPPN(inquiryNo, slotSelected);
        },
        GetSlotInquiryGPPN: function (inquiryNo, slotSelected) {
            var self = this;

            this.$GetSlotInquiryGPPN(slotSelected, inquiryNo)
           .then(function (resp) {

               if (resp.data.ResponseType == ResponseType.Success) {
                   var gppnInformation = resp.data.Content;
                   if (((gppnInformation.PartRequested) && gppnInformation.PartRequested != gppnInformation.PartSlotted)) {
                       ShowMessage(ResponseType.Validation, "Replace Slot Part Number")
                       eventHub.$emit('currentSlotPartValidation', true, gppnInformation.PartSlotted, gppnInformation.PartRequested);
                   }
                   else {
                       eventHub.$emit('proceedWithReplacementAndLinkAction', null);
                   }
               }
               else {
                   ShowMessage(resp.data.ResponseType, resp.data.Message)
               }


           }, function (error) { console.log(error); });
        },
        LinkInquiryNumberToAccessory: function (inquiryObject) {
            // It Creates Phantom Number

            var self = this;

            this.$LinkAccySlotDemand(self.accesorySelected, inquiryObject)
           .then(function (resp) {

               if (resp.data.ResponseType == ResponseType.Success) {
                   var content = resp.data.Content;
                   self.accesorySelected.InquiryNo = inquiryObject.InquiryNo;

                   var grid = $("#dataGrid").dxDataGrid("instance");
                   UpdateObjectBasedOnProperties(grid.getSelectedRowsData()[0], self.accesorySelected);
                   $("#dataGrid").dxDataGrid("instance").refresh();
               }
               ShowMessage(resp.data.ResponseType, resp.data.Message);


           }, function (error) { console.log(error); });
        },
        SendProductionDataToCRM: function (slotObjectSelectedByUser) {
            var self = this;
            
            this.$SendProductionDataToCRM(slotObjectSelectedByUser.InquiryNo, slotObjectSelectedByUser)
           .then(function (resp) {

               ShowMessage(resp.data.ResponseType, resp.data.Message)

           }, function (error) { console.log(error); });
        },


        EnableInquiriesFunction: function () {

            if (self.userInformation.RoleId == 2) {
                $(".contextMenu").dxContextMenu({
                    dataSource: [
                            { text: ' Remove Inquiry', icon: 'dx-icon-remove' },
                            { text: ' Add Inquiry', icon: 'dx-icon-add' },
                    ],
                    width: 200,
                    target: "#inquiry",
                    itemTemplate: function (itemData, itemIndex, itemElement) {
                        var template = $('<div></div>');
                        if (itemData.icon) {
                            template.append('<span class="' + itemData.icon + '"><span>');
                        }
                        if (itemData.items) {
                            template.append('<span class="dx-icon-spinright"><span>');
                        }
                        template.append(itemData.text);
                        return template;
                    },
                    onItemClick: function (e) {
                        if (!e.itemData.items) {
                            if (e.itemData.text == ' Remove Inquiry') {
                                app.$children[0].RemoveInquiryNumber();
                            }
                            else {
                                eventHub.$emit('getInquiriesList', this.productLine);

                                $('#InquiriesModal').modal();
                                $('#InquiriesModal').modal('open');
                            }
                        }
                    }
                });
            }
        },
        EnableCashList: function () {
            // Master Scheduler
            if (self.userInformation.RoleId == 1) {


                $(".addToCashListMenu").dxContextMenu({
                    dataSource: [
                            { text: ' Add to Cash List', icon: 'dx-icon-add' }
                    ],
                    width: 200,
                    target: "#slotNo",
                    itemTemplate: function (itemData, itemIndex, itemElement) {
                        var template = $('<div></div>');
                        if (itemData.icon) {
                            template.append('<span class="' + itemData.icon + '"><span>');
                        }
                        if (itemData.items) {
                            template.append('<span class="dx-icon-spinright"><span>');
                        }
                        template.append(itemData.text);
                        return template;
                    },
                    onItemClick: function (e) {
                        if (!e.itemData.items) {
                            if (e.itemData.text == ' Add to Cash List') {
                                self.AddToCashList();
                            }
                        }
                    }
                });
            }
        },
        ResetLayout: function (formId) {


            this.$ResetLayoutService(formId)
           .then(function (resp) {
               if (resp.data.ResponseType == ResponseType.Success) {
                   var content = resp.data.Content;
               }
               ShowMessage(resp.data.ResponseType, resp.data.Message)
           },
           function (error) {
               console.log(error);
           });

        },
        UpdateLayout: function () {
            var self = this;

            self.CreateLayoutObject(app.slotsColumnsSettings);

            this.$UpdateLayoutService(self.layout, app.formId)
           .then(function (resp) {
               if (resp.data.ResponseType == ResponseType.Success) {
                   var content = resp.data.Content;
               }
               ShowMessage(resp.data.ResponseType, resp.data.Message)
           },
           function (error) {
               console.log(error);
           });
        },
        CreateLayoutObject: function (columnsSettings) {
            var self = this;
            var dataGridInstance = $("#dataGrid").dxDataGrid("instance");
            dataGridInstance.beginUpdate();
            dataGridInstance.endUpdate();
            self.layout = [];


            for (var i = 0; i < columnsSettings.length; i++) {
                var isItVisible = dataGridInstance.columnOption(i, "visible");
                self.layout.push({
                    dataField: dataGridInstance.columnOption(i, "dataField"),
                    visibleIndex: dataGridInstance.columnOption(i, "visibleIndex"),
                    //visible: columnsSettings[iteration].visible
                    visible: isItVisible,
                    formId: self.formId,

                });
            }
        },

        // START Accessory Methods, I'll be moving to own file

        UpdateAccesorySlot: function () {
            //var self = this;
            var IsThereAnyValidation = false;
            var gpSlotAttachedToAccessory = null;

            self.UpdateAccessoryDatesInSlot();

            this.$GetSlotBySlotNumber(self.accesorySelected.GPSlot).then(function (resp) {
                gpSlotAttachedToAccessory = resp.data.Content;

                self.$UpdateAccesorySlotService(self.accesorySelected).then(function (resp) {
                    for (var i = 0; i < resp.data.length; i++) {
                        if (resp.data[i].ResponseType != ResponseType.Success) {

                            ShowMessage(resp.data[i].ResponseType, resp.data[i].Message)
                            IsThereAnyValidation = true;
                        }
                    }
                    if (!IsThereAnyValidation) {

                        ShowMessage(resp.data[0].ResponseType, resp.data[0].Message);

                        if (self.userInformation.RoleId == 2 && (self.accesorySelected.GPSlot != null && self.accesorySelected.GPSlot.length > 0) && gpSlotAttachedToAccessory.InquiryNo != null) {

                            ShowMessage(resp.data[0].ResponseType, 'Sending data to CRM..');
                            self.$UpdateAccessorySlotServiceCRM(self.accesorySelected.GPSlot).then(function (resp) {
                                ShowMessage(resp.data.ResponseType, resp.data.Message);
                            }, function (error) {

                            });
                        }


                        UpdateObjectBasedOnProperties(self.selectedDataGridRow, resp.data[0].Content);
                        $("#dataGrid").dxDataGrid("instance").refresh();
                    }
                    else if (resp.data.length > 1 && resp.data[0].Message == "The commit date you have requested for this Accessory is not the same commit date for it's attached GP Slot.") {

                        UpdateObjectBasedOnProperties(self.selectedDataGridRow, resp.data[1].Content);
                        $("#dataGrid").dxDataGrid("instance").refresh();
                    }

                }, function (error) {
                    console.log(error);
                });

            }, function (error) {
                console.log(error);
            });
        },
        UpdateAccessoryDatesInSlot: function () {


            var self = this;
            self.accesorySelected.BlDate = ValidateChangeInDateAndAddItOffset(self.accesoriesDatesFormatted.BlDate);
            self.accesorySelected.TestDate = ValidateChangeInDateAndAddItOffset(self.accesoriesDatesFormatted.TestDate);
            self.accesorySelected.DlvrDate = ValidateChangeInDateAndAddItOffset(self.accesoriesDatesFormatted.DlvrDate);
            self.accesorySelected.SchgcDate = ValidateChangeInDateAndAddItOffset(self.accesoriesDatesFormatted.SchgcDate);
            self.accesorySelected.CommitDate = ValidateChangeInDateAndAddItOffset(self.accesoriesDatesFormatted.CommitDate);
        },
        // Accessory selected from detail view of linked accessories
        UpdateAccesorySelectedObjectProperties: function (accesory) {
            var self = this;
            if (accesory == null)
                return;
            UpdateObjectBasedOnProperties(self.accesorySelected, accesory);
            self.FormatDatesOfAccySlotSelected(accesory);

        },
        FormatDatesOfAccySlotSelected: function (accesory) {
            var self = this;
            debugger;
            self.accesoriesDatesFormatted.BlDate = formatDate(accesory.BlDate)
            self.accesoriesDatesFormatted.TestDate = formatDate(accesory.TestDate);
            self.accesoriesDatesFormatted.DlvrDate = formatDate(accesory.DlvrDate);
            self.accesoriesDatesFormatted.SchgcDate = formatDate(accesory.SchgcDate);
            self.accesoriesDatesFormatted.CommitDate = formatDate(accesory.CommitDate);
        },


        // START: DevExtreme accessory related methods

        selectedAccessory: function (accessory) {
            this.UpdateAccesorySelectedObjectProperties(accessory);
        },
        refreshAccessoryInformation: function (accessoryData) {
            var self = this;
            if (self.isThereAnyPermissionOfEditability) {

                var productLine = self.getAccessoryProductLine(accessoryData);
                self.refreshAccessoryCatalogs(accessoryData, productLine);
                self.callPostGetAccessoryQuery(accessoryData);
            }
        },
        callPostGetAccessoryQuery: function (accessoryData) {
            var self = this;
            var parameters = "";

            parameters = self.generateAccessoryJSONStringifyParameters(accessoryData.ASlot);
            $.post(Objects.path + '/Accesories/GetAccesoryQuery', { parameters: parameters }).done(function (result) {

                self.refreshAccessoryDataGridRowInformation(result);
                self.updateDevExtremeDataGrid();

                // Re-bind accessorySelectedObject
                self.selectedAccessory(accessoryData);
                self.openAccessoryModal();
            });
        },
        // NOTE: Create a correct implementation instead of use this method
        generateAccessoryJSONStringifyParameters: function (accessorySlotNumber) {
            return JSON.stringify({ "CriteriaId": 1, "CriteriaQuery": accessorySlotNumber });
        },
        getAccessoryProductLine: function (accessoryData) {
            var self = this;
            return accessoryData.ASlot.substring(1, 2);
        },
        getAccessoryType: function (accessoryData) {
            var self = this;
            return accessoryData.Assy;
        },
        refreshAccessoryCatalogs: function (accessoryData, productLine) {
            var self = this;

            var accesoryType = self.getAccessoryType(accessoryData)

            self.lovAccessoryList =
            self.catalogs.LovAccessoryList.filter(function (partNumber) {
                return partNumber.ProductLine == productLine &&
                    partNumber.AssyTypeId == accesoryType.AccesoryTypeId;
            });
        },
        refreshAccessoryDataGridRowInformation: function (accessoryResult) {
            var self = this;
            var firstAccesoryOnResult = null;
            var firstElementOnList = 0;

            firstAccesoryOnResult = accessoryResult.data[firstElementOnList];
            UpdateObjectBasedOnProperties(self.selectedDataGridRow, firstAccesoryOnResult);
        },
        updateDevExtremeDataGrid: function () {
            $("#dataGrid").dxDataGrid("instance").refresh();
        },
        openAccessoryModal: function () {
            $('#accesoryDetialsTemplate').modal('open');
        },

        // END: DevExtreme accessory related methods



        // Ends Accessory Methods


        // START Non OSS general methods

        addOSS: function () {
            if (this.productLine == null || this.productLine == "") {
                ShowMessage(ResponseType.Validation, 'You must first set your Preferences.  Click on Actions, then Preferences.');
            }
            else {
                eventHub.$emit('openOSSNonDemand', this.productLine, false);
            }
        },
        editOSS: function () {
            eventHub.$emit('openOSSNonDemand', this.productLine, true);
        },
        NonOSSAdded: function (inquiryNo) {
            this.inquiryNumber = inquiryNo;
            this.slotSelected.InquiryNo = inquiryNo;
            $("#dataGrid").dxDataGrid("instance").refresh();
        },


        // ENDS Non OSS general methods


        // STARTS GP Part Number methods
        addGPPartNumber: function () {
            if (this.productLine == null || this.productLine == "") {
                ShowMessage(ResponseType.Validation, 'You must first set your Preferences.  Click on Actions, then Preferences.');
            }
            else {
                eventHub.$emit('getCategories');
                $('#addGPComponent').modal();
                $('#addGPComponent').modal('open');
            }
        }

        // ENDS GP Part Number
    }
});