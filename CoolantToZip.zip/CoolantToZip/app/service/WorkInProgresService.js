﻿getPath = function () {
    if (document.location.port == "") {
        var origin = document.location.origin;
        var applicationName = document.location.pathname.split("/")[1];
        if (applicationName.toLowerCase() == "wwps") {
            return origin + "/" + applicationName;
        }
        else {
            return origin;
        }
    }
    return document.location.origin;
};
var Objects = {
    path: getPath()
};

var WorkInProgresService = {
    install: function (Vue, options) {

        Vue.prototype.$GetWorkInProgresService = function (productionPathCode) {
            return axios.post(Objects.path + "/WIP/GetWorkInProgress", { "productionPathCode": productionPathCode });
        }

        Vue.prototype.$GetWorkInProgressLocationsService = function () {
            return axios.post(Objects.path + "/WIP/GetWorkInProgressLocations");
        }

        Vue.prototype.$MoveOutOfWipService = function (slotNumber) {
            return axios.post(Objects.path + "/WIP/MoveOutOfWip", { "slotNumber": slotNumber });
        }

        Vue.prototype.$MoveWipForwardService = function (slotNumber, stepsInBoard) {
            return axios.post(Objects.path + "/WIP/MoveWipForward", {
                "slotNumber": slotNumber,
                "stepsInBoard": stepsInBoard
            });
        }

        Vue.prototype.$MoveWipBackwardService = function (slotNumber, stepsInBoard) {
            return axios.post(Objects.path + "/WIP/MoveWipBackward", {
                "slotNumber": slotNumber,
                "stepsInBoard": stepsInBoard
            });
        }

        Vue.prototype.$MoveToReadyToShipService = function (slotNumber) {
            return axios.post(Objects.path + "/WIP/MoveToReadyToShip", {
                "slotNumber": slotNumber
            });
        }

        Vue.prototype.$MoveToAnotherSolarFacilityService = function (slotNumber) {
            return axios.post(Objects.path + "/WIP/MoveToAnotherSolarFacility", {
                "slotNumber": slotNumber
            });
        }
    }
};