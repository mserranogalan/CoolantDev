﻿var Functions = {
    install: function (Vue, options) {
        Vue.prototype.$Contains = function(main, search) {
            main = TrimObject(main);
            search = TrimObject(search);

            var contains = ContainsStringObject(main, search);
            return contains;
        }

        Vue.prototype.$ContainsAllWords = function (main, search) {
            main = TrimObject(main);
            search = TrimObject(search);

            var array = search.split(" ");
            var containsAll = Enumerable.From(array).Where(function (x) { return ContainsStringObject(main, x) }).ToArray().length == array.length

            return containsAll;
        }
    }
}

function TrimObject(object) {
    if (object === undefined) {
        object = "";
    }

    else if (object === null) {
        object = "";
    }

    return object.trim();
}

function ContainsStringObject(main, search) {
    //Convert both variables to upper case
    var mainUpper = main.toUpperCase();
    var searchUpper = search.toUpperCase();

    //Retrieve index if matches
    var indexOf = mainUpper.indexOf(searchUpper, 0);
    //If indexOf is greater than -1 is because a match was found
    var contains = indexOf > -1;

    return contains;
}

// This is just to update objects based in other ones with same structure
// For example when you try to update a slot basic details and the update is success in backend side
// You can proceed to update the row in the table from where you are selecting the slot
// the previous example allows to broke the binding of the table and the edition
function UpdateObjectBasedOnProperties(objectToUpdate, objectWithLatestData) {
    if (objectWithLatestData != null && objectToUpdate != null)
    {
        for (var i = 0; i < Object.keys(objectWithLatestData).length; i++) {

            if (Object.keys(objectWithLatestData)[i] in objectToUpdate)
            {
                objectToUpdate[Object.keys(objectWithLatestData)[i]] = objectWithLatestData[Object.keys(objectWithLatestData)[i]];
            }
        }
    }
        
}

function DisplayFields (propertiesToDisplay, formFieldAccess) {
    var self = this;
    var isThereAnyPermissionOfEditability = false;
    for (var i = 0; i < formFieldAccess.length; i++) {

        if (propertiesToDisplay[formFieldAccess[i].CPropertyName]) {
            propertiesToDisplay[formFieldAccess[i].CPropertyName].Visible = true;
            isThereAnyPermissionOfEditability = true;
        } 
    }
    return isThereAnyPermissionOfEditability;
}
function mountElements() {
    $('.modal').modal();
    $('.datepicker').pickadate({
        labelMonthNext: 'Proximo mes',
        labelMonthPrev: 'Mes anterior',
        selectMonths: true, // Creates a dropdown to control month
        selectYears: 1, // Creates a dropdown of 15 years to control year
        onStart: $('.picker').appendTo('body')
    });
    $('.dropdown-trigger').dropdown();
    $('.tooltipped').tooltip({ delay: 50 });

    $('.tabs').tabs();
    // Ends Materialize 
    $(document).on("mouseover", ".tooltip-container", function (event) {
        $(this).find("span.new-tooltip").show();
    }).on("mouseout", function () {
        $(this).find("span.new-tooltip").hide();
    });
    // Dates From ... To ... filter
    $("#mainFilter").on("click", function (event) {
        $('#datesFromToModal').modal('open');
    });
    // Functions
    $(".menu-trigger").on("click", function () {
        // $(".st-ctx-menu").hide();
        $(this).next().show();
    });
    $(window).click(function () {
        $(".menu-trigger").next("ul").hide();
    });
    $(".menu-trigger, .st-ctx-menu").on("click", function (event) {
        event.stopPropagation();
    });
    $(".filter-tag").on("click", function () {
        $(this).remove();
    });

}

// The v-calendar requires the correct format to binding/display dates
function formatDate (date) {
    if (!date) {
        return null;
    }
    else {
        return new Date(date);
    }
}

function GetIndexOfObject(list, value) {
    for (var i = 0; i < list.length; i++) {
        if (list[i].hasOwnProperty('PropertyName') && list[i]['PropertyName'] === value) {
            return i;
        }
    }
    return -1;
}

function GetDifferenceInHoursOfUTCTimeVsCurrentLocationTime() {
    moment.tz.add('America/Los_Angeles|PST PDT|80 70|01010101010|1Lzm0 1zb0 Op0 1zb0 Rd0 1zb0 Op0 1zb0 Op0 1zb0');
    moment.tz.link('America/Los_Angeles|US/Pacific');

    var hourPacificStandardTime = moment(moment.tz(moment().format(), "US/Pacific").format('YYYY-MM-DD HH:mm'));
    var hourCurrentLocationTime = moment(moment().format('YYYY-MM-DD HH:mm'));
    var differenceBetweenTimes  = hourCurrentLocationTime.diff(hourPacificStandardTime, 'hours');

    return differenceBetweenTimes;
}

function ValidateChangeInDateAndAddItOffset(date) {
    return moment(date).format("YYYY-MM-DD");
}

function InitializeLoadPanel() {
    loadPanel = $(".loadpanelMaster").dxLoadPanel({
        visible: false,
        showIndicator: true,
        showPane: true,
        shading: true,
        closeOnOutsideClick: false,
        onShown: function () {
        },
        onHidden: function () {
        }
    }).dxLoadPanel("instance");

}