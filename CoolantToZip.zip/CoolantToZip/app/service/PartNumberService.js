﻿getPath = function () {
    if (document.location.port == "") {
        var origin = document.location.origin;
        var applicationName = document.location.pathname.split("/")[1];

        if (applicationName.toLowerCase() == "wwps") {
            return origin + "/" + applicationName;
        }
        else {
            return origin;
        }
    }
    return document.location.origin;
};

var Objects = {
    path: getPath()
};

var PartNumberService = {
    install: function (Vue, options) {

        Vue.prototype.$getProductCategories = function () {
            return axios.post(Objects.path + "/PartNumber/GetProductCategories");
        }
        Vue.prototype.$addGPPartNumber = function (GPPartNumber) {
            return axios.post(Objects.path + "/PartNumber/AddGPPartNumber", { "GPPartNumber": GPPartNumber });
        }

    }
};