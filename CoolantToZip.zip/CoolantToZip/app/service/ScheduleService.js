﻿getPath = function () {
    if (document.location.port == "") {
        var origin = document.location.origin;
        var applicationName = document.location.pathname.split("/")[1];

        if (applicationName.toLowerCase() == "wwps") {
            return origin + "/" + applicationName;
        }
        else {
            return origin;
        }
    }
    return document.location.origin;
};
var Objects = {
    path: getPath()
};

var ScheduleService = {
    install: function (Vue, options) {

        Vue.prototype.$getProductLines = function () {
            return axios.post(Objects.path + "/Schedules/GetProductLines");
        }

        Vue.prototype.$getNextGPSlot = function (productLine) {
            return axios.post(Objects.path + "/Schedules/GetNextGPSlot", { "productLine": productLine });
        }


        Vue.prototype.$getNextAccesorySlot = function (productLine) {
            return axios.post(Objects.path + "/Schedules/GetNextAccesorySlot", { "productLine": productLine });
        }

        Vue.prototype.$getNumberOfPendingApprovals = function (productLine) {
            return axios.post(Objects.path + "/Schedules/GetNextAccesorySlot", { "productLine": productLine });
        }

        Vue.prototype.$OPSNotificationsExist = function (valuestreams) {
            return axios.post(Objects.path + "/Schedules/OPSNotificationsExist", { "valuestreams": valuestreams });
        }
        Vue.prototype.$PMNotificationsExist = function (productLine) {
            return axios.post(Objects.path + "/Schedules/PMNotificationsExist", { "productLine": productLine });
        }

        Vue.prototype.$getPMAccesoryScheduleNotifications = function (productLine) {
            return axios.post(Objects.path + "/Schedules/GetPMAccesoryScheduleNotifications", { "productLine": productLine });
        }

        Vue.prototype.$getPMGPScheduleNotifications = function (productLine) {
            return axios.post(Objects.path + "/Schedules/GetPMGPScheduleNotifications", { "productLine": productLine });
        }

        Vue.prototype.$approvePMGPSchedules = function (gpSchedules) {
            return axios.post(Objects.path + "/Schedules/ApprovePMGPSchedules", { "gpSchedules": gpSchedules });
        }

        Vue.prototype.$approvePMAccesorySchedules = function (accesorySchedules) {
            return axios.post(Objects.path + "/Schedules/ApprovePMAccesorySchedules", { "accesorySchedules": accesorySchedules });
        }

        Vue.prototype.$getOPSAccesoryScheduleNotifications = function (valuestreams) {
            return axios.post(Objects.path + "/Schedules/GetOPSAccesoryScheduleNotifications", { "valuestreams": valuestreams });
        }

        Vue.prototype.$getOPSAccesoryMasterScheduleNotifications = function (valuestreams) {
            return axios.post(Objects.path + "/Schedules/GetOPSAccesoryMasterSchedulesNotifications", { "valuestreams": valuestreams });
        }

        Vue.prototype.$getOPSGPScheduleNotifications = function (valuestreams) {
            return axios.post(Objects.path + "/Schedules/GetOPSGPScheduleNotifications", { "valuestreams": valuestreams });
        }

        Vue.prototype.$approveOPSGPSchedules = function (gpSchedules) {
            return axios.post(Objects.path + "/Schedules/ApproveOPSGPSchedules", { "gpSchedules": gpSchedules });
        }
        
        Vue.prototype.$approveAllOPSAccesorySchedules = function (valuestreams, listOfSlotsIds) {
            return axios.post(Objects.path + "/Schedules/ApproveAllOPSAccesorySchedules",
                {
                    "valuestreams": valuestreams,
                    "listOfSlotsIds": listOfSlotsIds
                });
        }

        Vue.prototype.$approveAllOPSAccesoryMasterSchedules = function (valuestreams, listOfSlotsIds) {
            return axios.post(Objects.path + "/Schedules/ApproveAllOPSAccesoryMasterSchedules",
                {
                    "valuestreams": valuestreams,
                    "listOfSlotsIds": listOfSlotsIds
                });
        }

        Vue.prototype.$approveOPSAccesorySchedules = function (accySchedules) {
            return axios.post(Objects.path + "/Schedules/ApproveOPSAccesorySchedules", { "accySchedules": accySchedules });
        }

        Vue.prototype.$approveOPSAccesoryMasterSchedules = function (accySchedules) {
            return axios.post(Objects.path + "/Schedules/ApproveOPSAccesoryMasterSchedules", { "accySchedules": accySchedules });
        }

        Vue.prototype.$getScheduleConfigurations = function (productLine, assemblyType) {
            return axios.post(Objects.path + "/Schedules/GetScheduleConfigurations", { "productLine": productLine, "assemblyType": assemblyType });
        }

        Vue.prototype.$getSlotCategories = function (productLine) {
            return axios.post(Objects.path + "/Schedules/GetSlotCategories", { "productLine": productLine });
        }

        Vue.prototype.$getAssemblyTypes = function (isAccesory) {
            return axios.post(Objects.path + "/Schedules/GetAssemblyTypes", { "isAccesory": isAccesory });
        }

        Vue.prototype.$addGPSlot = function (newGPSlot) {
            return axios.post(Objects.path + "/Schedules/AddGPSlot", { "newGPSlot": newGPSlot });
        }

        Vue.prototype.$addAccesorySlot = function (newAccesorySlot) {
            return axios.post(Objects.path + "/Schedules/AddAccesorySlot", { "newAccesorySlot": newAccesorySlot });
        }

    }
};
