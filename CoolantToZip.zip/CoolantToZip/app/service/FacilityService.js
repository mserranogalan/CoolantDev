﻿getPath = function () {
    if (document.location.port == "") {
        var origin = document.location.origin;
        var applicationName = document.location.pathname.split("/")[1];
        if (applicationName.toLowerCase() == "wwps") {
            return origin + "/" + applicationName;
        }
        else {
            return origin;
        }
    }
    return document.location.origin;
};
var Objects = {
    path: getPath()
};

var FacilityService = {
    install: function (Vue, options) {

        Vue.prototype.$getFacilities = function () {
            return axios.post(Objects.path + "/Facilities/GetFacilities");
        }
    }
};