﻿getPath = function () {
    if (document.location.port == "") {
        var origin = document.location.origin;
        var applicationName = document.location.pathname.split("/")[1];
        if (applicationName.toLowerCase() == "wwps") {
            return origin + "/" + applicationName;
        }
        else {
            return origin;
        }
    }
    return document.location.origin;
};
var Objects = {
    path: getPath()
};

var HomeService = {
    install: function (Vue, options) {
        //START Home ajax calls that should be here 
        Vue.prototype.$getEssentialInformationService = function () {
            return axios.post(Objects.path + "/Home/GetEssentialInformation");
        }
        // VIEW: Production Path Planned Exists
        Vue.prototype.$getProductionPathScheduleQueryService = function (dateField, dateStart, dateEnd, productionPath, facilityCodes) {
            return axios.post(Objects.path + "/Home/GetProductionPathScheduleQuery", { "dateField": dateField, "dateStart": dateStart, "dateEnd": dateEnd, "productionPath": productionPath, "facilityCodes": facilityCodes });
        }
        // VIEW: Production Family Filter 
        Vue.prototype.$getPMProductionGroupScheduleQueryService = function (dateField, dateStart, dateEnd, productionPath, facilityCodes) {
            return axios.post(Objects.path + "/Home/GetPMProductionGroupScheduleQuery", { "dateField": dateField, "dateStart": dateStart, "dateEnd": dateEnd, "productionPath": productionPath, "facilityCodes": facilityCodes });
        }
        // VIEW: Production Line Filter
        Vue.prototype.$getNewPMScheduleQueryService = function (dateField, dateStart, dateEnd, productionLines, facilityCodes) {
            return axios.post(Objects.path + "/Home/GetNewPMScheduleQuery_Result", { "dateField": dateField, "dateStart": dateStart, "dateEnd": dateEnd, "productionLines": productionLines, "facilityCodes": facilityCodes });
        }
        Vue.prototype.$UpdateGPSlotService = function (slot) {
            return axios.post(Objects.path + "/Home/UpdateGPSlot", { "slot": slot });
        },

        Vue.prototype.$UpdateGPSlotServiceCRM = function (InquiryNo) {            
            return axios.post(Objects.path + "/Home/SendGPSlotUpdateToCRM", { "InquiryNo": InquiryNo });
        },

        Vue.prototype.$UpdateOSSServiceCRM = function (InquiryNo) {            
            return axios.post(Objects.path + "/Home/SendOSSUpdateToCRM", { "InquiryNo": InquiryNo });
        },


        //END Home ajax calls that should be here 

        // OSS Details function
        Vue.prototype.$GetDemandSlotDetailBySlotNo = function (slotNo) {
          
            return axios.post(Objects.path + "/OSS/GetDemandSlotDetailBySlotNo", { "slotNo": slotNo });
        }
        Vue.prototype.$UpdateOSSDetails = function (slotOSSGeneralInformation) {
            return axios.post(Objects.path + "/OSS/UpdateOSSDetails", { "slotOSSGeneralInformation": slotOSSGeneralInformation });
        }


        Vue.prototype.$GetSlotBySlotNumber = function (slotNo) {
            return axios.post(Objects.path + "/Home/GetSlotBySlotNumber", { "slotNo": slotNo });
        }

        Vue.prototype.$UpdateUserPreference = function (producLine) {
            return axios.post(Objects.path + "/User/UpdateUserPreference", { "producLine": producLine });
        }

        Vue.prototype.$GetDemandService = function (producLine, facility, ossStatus) {
            return axios.post(Objects.path + "/Inquiries/GetDemand", {
                "vchProductLine": producLine,
                "vchFacility": facility,
                "vchOssStatus": ossStatus
            });
        }

        Vue.prototype.$RemoveInquiryNumberService = function (slotSelected) {
            return axios.post(Objects.path + "/Inquiries/RemoveInquiryNumber", {
                "slotSelected": slotSelected,
            });
        }

        Vue.prototype.$LinkInquiryNumberService = function (slotNumber, inquiryNumber, aswerForPartNumberReplacement) {
            return axios.post(Objects.path + "/Inquiries/LinkInquiryNumber", {
                "slotToModified": slotNumber,
                "inquiryNumber": inquiryNumber,
                "isRequiredReplaceOfPN": aswerForPartNumberReplacement
            });
        }

        Vue.prototype.$GetSlotInquiryGPPN = function (slotToModified, inquiryNumber) {
            return axios.post(Objects.path + "/Inquiries/GetSlotInquiryGPPN", {
                "slotToModified": slotToModified,
                "inquiryNumber": inquiryNumber
            });
        }

        Vue.prototype.$LinkSlotToDemand = function (slotNumber, inquiryNumber, isRequiredReplacePN, bWithinFence, RecommitReasonCode) {
            return axios.post(Objects.path + "/Inquiries/LinkSlotToDemand", {
                "slotNumber": slotNumber,
                "inquiryNumber": inquiryNumber,
                "isRequiredReplacePN": isRequiredReplacePN,
                "bWithinFence": bWithinFence,
                "RecommitReasonCode": RecommitReasonCode

            });
        }

        // this should be in master service
        Vue.prototype.$UpdateLayoutService = function (currentLayout, formId) {
            return axios.post(Objects.path + "/ColumnSettings/UpdateLayout", {
                "currentLayout": currentLayout, "formId":formId
            });
        }

        Vue.prototype.$GetUserInformationService = function () {
            return axios.post(Objects.path + "/Home/GetUserInformation");
        }

        //Wip

        Vue.prototype.$AddToCashListService = function (slotNumber) {
            return axios.post(Objects.path + "/WIP/AddToCashList", { "slotNumber": slotNumber });
        }

        // Testing DevExtreme
        Vue.prototype.$TestingDevExpressService = function () {
            return axios.post(Objects.path + "/Home/TestingDevExpress");
        }

        Vue.prototype.$UpdateOnHoldFlagService = function (ossDetailsToModified) {
            return axios.post(Objects.path + "/OSS/UpdateOnHoldFlag", {
                "ossDetailsToModified": ossDetailsToModified
            });
        }

        Vue.prototype.$SendProductionDataToCRM = function (inquiryNumber) {
            return axios.post(Objects.path + "/CRM/SendProductionDataToCRM", {
                "inquiryNumber": inquiryNumber
            });
        }


    }
}