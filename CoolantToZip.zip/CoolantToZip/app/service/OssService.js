﻿getPath = function () {
    if (document.location.port == "") {
        var origin = document.location.origin;
        var applicationName = document.location.pathname.split("/")[1];
        if (applicationName.toLowerCase() == "wwps") {
            return origin + "/" + applicationName;
        }
        else {
            return origin;
        }
    }
    return document.location.origin;
};
var Objects = {
    path: getPath()
};

var OssService = {
    install: function (Vue, options) {

        
        Vue.prototype.$getOSSDetail = function ( inquiryNumber) {
            return axios.post(Objects.path + "/OSS/GetOSSDetail", { "inquiryNumber": inquiryNumber });
        }

        Vue.prototype.$checkGPSlotForInquiry = function (gpSlot) {
            return axios.post(Objects.path + "/OSS/CheckGPSlotForInquiry", { "gpSlot": gpSlot });
        }

        Vue.prototype.$addNewOSS = function (newOSS, replacePartNumber) {
            return axios.post(Objects.path + "/OSS/AddNewOSS", { "newOSS": newOSS, "replacePartNumber": replacePartNumber
    });
        }

        Vue.prototype.$updateOSS = function (updatedOSS, slotNumber, isPartNumberReplaced) {
            return axios.post(Objects.path + "/OSS/UpdateOSS", { "updatedOSS": updatedOSS, "slotNumber": slotNumber, "isPartNumberReplaced": isPartNumberReplaced });
        }

        Vue.prototype.$getOssStatus = function () {
            return axios.post(Objects.path + "/OSS/GetOSSOrderStatus");
        }

        Vue.prototype.$getRecommitReasons = function () {
            return axios.post(Objects.path + "/OSS/GetRecommitReasons");
        }

        Vue.prototype.$getOssPartNumbers = function (productLine) {
            return axios.post(Objects.path + "/OSS/GetOSSPartNumbers", { "productLine": productLine });
        }

        Vue.prototype.$getOssWorkscopes = function (productLine) {
            return axios.post(Objects.path + "/OSS/GetOSSWorkscopes", { "productLine": productLine });
        }

        Vue.prototype.$getOssSlotProductLine = function (slotNumber) {
            return axios.post(Objects.path + "/OSS/GetOssSlotProductLine", { "slotNumber": slotNumber });
        }
    }

};