﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using log4net;
using SolarApp.DataAccess.Repositories;
using SolarApp.Context;
using System.Threading;
using Coolant.BLL.Contexts;
using Coolant.BLL.ViewModels;
using Newtonsoft.Json;

namespace Coolant.Controllers
{
    public class UsersController : Controller
    {
        private static readonly ILog Logger = LogManager.GetLogger(System.Environment.MachineName);
        private readonly UsersContext _usersContext;
        private List<UsersVM> Users;

        public UsersController()
        {
            _usersContext = new UsersContext();
        }

        public ActionResult UsersPage()
        {
            return View();
        }

        public ActionResult GetAllUsers()
        {
            try
            {
                Users = _usersContext.GetAllUsers();
            }
            catch (Exception exception)
            {
                Logger.Error(exception);
            }
            return Json(Users, JsonRequestBehavior.AllowGet);
        }

        public ActionResult UpdateUsers(UsersVM users)
        {
            return Json(_usersContext.UpdateUsers(users));
        }

        public ActionResult AddUser(UsersVM users)
        {
            return Json(_usersContext.AddUser(users));
        }

        public ActionResult Index()
        {
            try
            {
                Users = _usersContext.GetAllUsers();
            }
            catch (Exception exception)
            {
                Logger.Error(exception);
            }
            return Json(Users, JsonRequestBehavior.AllowGet);
        }

   









    }
}
