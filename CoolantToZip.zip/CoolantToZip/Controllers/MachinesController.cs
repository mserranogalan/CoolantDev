﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using log4net;
using SolarApp.DataAccess.Repositories;
using SolarApp.Context;
using System.Threading;
using Coolant.BLL.Contexts;
using Coolant.BLL.ViewModels;
using Newtonsoft.Json;

namespace Coolant.Controllers
{
    public class MachinesController : Controller
    {
        private static readonly ILog Logger = LogManager.GetLogger(System.Environment.MachineName);
        private readonly MachinesContext  _machinesContext;
        private List<MachinesVM> Machines;

        public MachinesController()
        {
            _machinesContext = new MachinesContext();
        }

        public ActionResult MachinesPage()
        {
            return View();
        }


        public ActionResult GetAllMachines()
        {
            try
            {
                Machines = _machinesContext.GetAllMachines();
            }
            catch (Exception exception)
            {
                Logger.Error(exception);
            }
            return Json(Machines, JsonRequestBehavior.AllowGet);
        }


        public ActionResult UpdateMachines(MachinesVM machines)
        {
            return Json(_machinesContext.UpdateMachines(machines));
        }

        public ActionResult AddMachine(MachinesVM machines)
        {
            return Json(_machinesContext.AddMachine(machines));
        }


        public ActionResult Index()
        {
            try
            {
                Machines = _machinesContext.GetAllMachines();
            }
            catch (Exception exception)
            {
                Logger.Error(exception);
            }
            return Json(Machines, JsonRequestBehavior.AllowGet);
        }


    }
}
