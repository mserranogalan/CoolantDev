﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using Coolant.DAL.Model;

namespace Coolant.BLL.ViewModels
{
    public static partial class Extensions
    {
        /// <summary>
        /// Method to convert an entity object to view model object
        /// </summary>
        /// <returns></returns>
        public static LeanWorkCenterVM ToLeanWorkCenterVM(this LeanWorkCenter leanworkcenter)
        {
            LeanWorkCenterVM leanworkcenterVm = leanworkcenter != null ? new LeanWorkCenterVM(leanworkcenter) : null;
            return leanworkcenterVm;
        }

        /// <summary>
        /// Method to convert an entity collection to a view model list
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public static List<LeanWorkCenterVM> ToLeanWorkCenterVMList(this IEnumerable<LeanWorkCenter> leanworkcenters)
        {
            List<LeanWorkCenterVM> leanworkcenterVm =
                leanworkcenters != null
                ? leanworkcenters.Select(ToLeanWorkCenterVM).ToList()
                : new List<LeanWorkCenterVM>();
            return leanworkcenterVm;
        }


        /// <summary>
        /// Method to convert an entity object to view model object
        /// </summary>
        /// <returns></returns>
        public static MachinesVM ToMachinesVM(this Machines machines)
        {
            MachinesVM machinesVm = machines != null ? new MachinesVM(machines) : null;
            return machinesVm;
        }

        /// <summary>
        /// Method to convert an entity collection to a view model list
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public static List<MachinesVM> ToMachinesVMList(this IEnumerable<Machines> machines)
        {
            List<MachinesVM> machinesVm = machines != null
                ? machines.Select(ToMachinesVM).ToList()
                : new List<MachinesVM>();
            return machinesVm;
        }


        /// <summary>
        /// Method to convert an entity object to view model object
        /// </summary>
        /// <returns></returns>
        public static UsersVM ToUsersVM(this Users users)
        {
            UsersVM usersVm = users != null ? new UsersVM(users) : null;
            return usersVm;
        }

        /// <summary>
        /// Method to convert an entity collection to a view model list
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public static List<UsersVM> ToUsersVMList(this IEnumerable<Users> users)
        {
            List<UsersVM> usersVm = users != null
                ? users.Select(ToUsersVM).ToList()
                : new List<UsersVM>();
            return usersVm;
        }

    }
}
