﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace Coolant.BLL.ViewModels
{
    public class RolsVM
    {
        /// <summary>
        /// Detail's ID
        /// </summary
        public int RoleId { get; set; }

        /// <summary>
        /// Rol's Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Is the detail visible to user and able to be worked on?
        /// 1 = Yes, 0 = No
        /// </summary>
        public bool IsActive { get; set; }
    }
}
