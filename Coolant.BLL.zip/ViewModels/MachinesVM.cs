﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using Coolant.DAL.Model;

namespace Coolant.BLL.ViewModels
{
    public class MachinesVM
    {
        /// <summary>
        /// Detail's ID
        /// </summary
        public int MachineId { get; set; }

        /// <summary>
        /// Name's Description
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Lean Work Center
        /// </summary>
        public int LeanWorkCenterId { get; set; }

        /// <summary>
        /// Minimum Concentration
        /// </summary>
        public decimal ConcentrationMinimun { get; set; }

        /// <summary>
        /// Maximun Concentration
        /// </summary>        
        public decimal ConcentrationMaximun { get; set; }

        /// <summary>
        /// Minimun PH
        /// </summary>
        public decimal PHMinimun { get; set; }

        /// <summary>
        /// Maximun PH
        /// </summary>
        public decimal PHMaximun { get; set; }

        /// <summary>
        /// there are only two values: OVERHAUL and MANUFACTURA) nvarchar(50)
        /// </summary>
        public int CAM { get; set; }

        /// <summary>
        /// Creation Date
        /// </summary>
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// User who registered it
        /// </summary>
        public int CreatedBy { get; set; }

        /// <summary>
        /// Is the detail visible to user and able to be worked on?
        /// 1 = Yes, 0 = No
        /// </summary>
        public bool IsActive { get; set; }


        /// <summary>
        /// Method to set all values to default
        /// </summary>
        private void EmptyObject()
        {
            MachineId = 0;
            Name = String.Empty;
            LeanWorkCenterId = 0;
            ConcentrationMinimun = 0;
            ConcentrationMaximun = 0;
            PHMinimun = 0;
            PHMaximun = 0;
            CAM = 0;
            CreatedBy = 0;
            IsActive = false;
        }

        /// <summary>
        /// Constructor
        /// </summary>
        public MachinesVM()
        {
            EmptyObject();
        }

        /// <summary>
        /// Constructor that creates a View Model based of an Entity object
        /// </summary>
        public MachinesVM(Machines machines)
        {
            EmptyObject();

            if (machines != null)
            {
                this.MachineId = machines.MachineId;
                this.Name = machines.Name;
                this.LeanWorkCenterId = machines.LeanWorkCenterId;
                this.ConcentrationMinimun = machines.ConcentrationMinimun;
                this.ConcentrationMaximun = machines.ConcentrationMaximun;
                this.PHMinimun = machines.PHMinimun;
                this.PHMaximun = machines.PHMaximun;
                this.CAM = machines.CAM;
                this.CreatedBy = machines.CreatedBy;
                this.IsActive = machines.IsActive;
            }
        }


        enum camEnum 
        {
            None,
            OVERHAUL = 1,
            MANUFACTURA = 2
        }

    }
}
