﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using Coolant.DAL.Model;

namespace Coolant.BLL.ViewModels
{
    public class LeanWorkCenterVM
    {
        /// <summary>
        /// Detail's ID
        /// </summary
        public int LeanWorkCenterId { get; set; }

        /// <summary>
        /// Name's Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Is the detail visible to user and able to be worked on?
        /// 1 = Yes, 0 = No
        /// </summary>
        public bool IsActive { get; set; }


        /// <summary>
        /// Method to set all values to default
        /// </summary>
        private void EmptyObject()
        {
            LeanWorkCenterId = 0;
            Description = String.Empty;
            IsActive = false;
        }

        /// <summary>
        /// Constructor
        /// </summary>
        public LeanWorkCenterVM()
        {
            EmptyObject();
        }

        /// <summary>
        /// Constructor that creates a View Model based of an Entity object
        /// </summary>
        /// <param name="user">Fills data to View Model</param>
        /// <param name="includeTasks"></param>
        public LeanWorkCenterVM(LeanWorkCenter leanWorkCenter)
        {
            EmptyObject();

            if (leanWorkCenter != null)
            {
                this.LeanWorkCenterId = leanWorkCenter.LeanWorkCenterId;
                this.Description = leanWorkCenter.Description;
                this.IsActive = leanWorkCenter.IsActive;
            }
        }

    }
}
