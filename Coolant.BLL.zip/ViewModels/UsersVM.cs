﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using Coolant.DAL.Model;

namespace Coolant.BLL.ViewModels
{
    public class UsersVM
    {
        /// <summary>
        /// Detail's ID
        /// </summary
        public int UserId { get; set; }

        /// <summary>
        /// User's Caterpillar Badge Number
        /// </summary>
        public string Badge { get; set; }

        /// <summary>
        /// Name's Description
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Lean Work Center FK
        /// </summary>
        public int LeanWorkCenterId { get; set; }

        /// <summary>
        /// User's Supervisor
        /// </summary>
        public int SupervisorId { get; set; }

        /// <summary>
        /// User's assigned role
        /// </summary>
        //[ForeignKey("RolId")]
        public int RolId { get; set; }

        /// <summary>
        /// Is the detail visible to user and able to be worked on?
        /// 1 = Yes, 0 = No
        /// </summary>
        public bool IsActive { get; set; }



        /// <summary>
        /// Method to set all values to default
        /// </summary>
        private void EmptyObject()
        {
            UserId = 0;
            Badge = String.Empty;
            Name = string.Empty;
            LeanWorkCenterId = 0;
            RolId = 0;
            SupervisorId = 0;
            IsActive = false;
        }

        /// <summary>
        /// Constructor
        /// </summary>
        public UsersVM()
        {
            EmptyObject();
        }

        /// <summary>
        /// Constructor that creates a View Model based of an Entity object
        /// </summary>
        public UsersVM(Users users)
        {
            EmptyObject();

            if (users != null)
            {
                this.UserId = users.UserId;
                this.Badge = users.Badge;
                this.Name = users.Name;
                this.LeanWorkCenterId = users.LeanWorkCenterId;
                this.RolId = users.RolId;
                this.SupervisorId = users.SupervisorId;
                this.IsActive = users.IsActive;
            }
        }



    }
}
