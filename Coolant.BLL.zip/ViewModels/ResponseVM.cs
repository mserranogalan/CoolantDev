﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using Coolant.DAL.Model;

namespace Coolant.BLL.ViewModels
{
    public class ResponseVM
    {
        public TypeResult Status { get; set; }
        public string Message { get; set; }
        public dynamic Content { get; set; }
        public List<string> Errors { get; set; }

        public enum TypeResult
        {
            [Description("Success")]
            Success = 0,
            [Description("Error")]
            Error = 1,
        }
    }
}
