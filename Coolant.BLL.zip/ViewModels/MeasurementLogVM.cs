﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace Coolant.BLL.ViewModels
{
    public class MeasurementLogVM
    {

        /// <summary>
        /// Detail's ID
        /// </summary
        public int MeasurementLogId { get; set; }

        /// <summary>
        /// Who Machine
        /// </summary
        public int MachineId { get; set; }


        /// <summary>
        /// User who registered it
        /// </summary>
        //[ForeignKey("UserId")]
        public int CreatedBy { get; set; }

        /// <summary>
        /// Creation Date
        /// </summary>
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Concentration Value. decimal (10,2)
        /// </summary>
        public float ConcentrationValue { get; set; }

        /// <summary>
        /// Minimum Concentration. decimal (10,2)
        /// </summary>
        public float MinConcentration { get; set; }

        /// <summary>
        /// Maximun Concentration. decimal (10,2)
        /// </summary>        
        public float MaxConcentration { get; set; }

        /// <summary>
        /// New Concentration Value. decimal (10,2)
        /// </summary>
        public float NewConcentrationValue { get; set; }

        /// <summary>
        /// Concentration Action Taken
        /// </summary>
        public string ConcentrationActionTaken { get; set; }

        /// <summary>
        /// PH Value. decimal (10,2)
        /// </summary>
        public float PHValue { get; set; }

        /// <summary>
        /// Minimum PH Value. decimal (10,2)
        /// </summary>
        public float MinPHValue { get; set; }

        /// <summary>
        /// Maximun PH Value. decimal (10,2)
        /// </summary>
        public float MaxPHValue { get; set; }

        /// <summary>
        /// New PH Value. decimal (10,2)
        /// </summary>
        public float NewPHValue { get; set; }

        /// <summary>
        /// PH Action Taken
        /// </summary>
        public string PHActionTaken { get; set; }

        /// <summary>
        /// Coolant Level
        /// </summary>
        public bool CoolantLevel { get; set; }

        /// <summary>
        /// Coolant Level Fixed
        /// </summary>
        public bool CoolantLevelFixed { get; set; }

        /// <summary>
        /// Rust Present
        /// </summary>
        public bool RustPresent { get; set; }

        /// <summary>
        /// Bad Smell
        /// </summary>
        public bool BadSmell { get; set; }

        /// <summary>
        /// Comments
        /// </summary>
        public string Comments { get; set; }

        /// <summary>
        /// Who is the supervisor that fixed a concentration or PH measure
        /// </summary>
        public int AuthorizedBy { get; set; }

        /// <summary>
        /// Date when supervisor has modified the record
        /// </summary>
        public DateTime AuthorizedOn { get; set; }
    }
}
