﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Text.RegularExpressions;
using Coolant.DAL.Repositories;
using Coolant.DAL.Model;
using Coolant.BLL.ViewModels;

namespace Coolant.BLL.Contexts
{
    public class MachinesContext
    {
        /// <summary>
        /// Current user's CWS ID
        /// </summary>
        private readonly string _currentUserBadge = HttpContext.Current.User.Identity.Name;

        /// <summary>
        /// Usage of repositories
        /// </summary>
        private readonly MachinesRepository _machinesRepository;
        private CurrentUserContext currentUser = new CurrentUserContext();
        public ResponseVM _response;

        /// <summary>
        /// Constructor
        /// </summary>
        public MachinesContext()
        {
            _machinesRepository = new MachinesRepository();
            _response = new ResponseVM();
        }

        /// <summary>
        /// Method to get a list of Machines
        /// </summary>
        /// <returns></returns>
        public List<MachinesVM> GetAllMachines()
        {
            List<Machines> entityList = _machinesRepository.GetAllMachines();
            List<MachinesVM> viewModelList = entityList.ToMachinesVMList();
            return viewModelList;
        }


        public ResponseVM UpdateMachines(MachinesVM machines)
        {
            Machines machinesTbl = new Machines
            {
                MachineId = machines.MachineId,
                Name = machines.Name,
                LeanWorkCenterId = machines.LeanWorkCenterId,
                ConcentrationMinimun = machines.ConcentrationMinimun,
                ConcentrationMaximun = machines.ConcentrationMaximun,
                PHMinimun = machines.PHMinimun,
                PHMaximun = machines.PHMaximun,
                CAM = machines.CAM,
                CreatedBy = machines.CreatedBy,
                IsActive = machines.IsActive
            };

            machinesTbl = _machinesRepository.UpdateMachines(machinesTbl);
            _response.Content = machinesTbl.ToMachinesVM();
            _response.Message = machinesTbl != null ? "The Machine updated" : "The Machine was not updated";
            return _response;
        }

        public ResponseVM AddMachine(MachinesVM machines)
        {
            Machines machinesTbl = new Machines 
            {

                Name = machines.Name,
                LeanWorkCenterId = machines.LeanWorkCenterId,
                ConcentrationMinimun = machines.ConcentrationMinimun,
                ConcentrationMaximun = machines.ConcentrationMaximun,
                PHMinimun = machines.PHMinimun,
                PHMaximun = machines.PHMaximun,
                CAM = machines.CAM,
                CreatedOn = DateTime.Now,
                CreatedBy = machines.CreatedBy,
                IsActive = machines.IsActive
            };

            bool result = _machinesRepository.AddMachine(machinesTbl);
            _response.Content = result ? machinesTbl.ToMachinesVM() : null;
            _response.Message = result ? "The Machine Added" : "The Machine was not Added";
            return _response;
        }

    }
}
