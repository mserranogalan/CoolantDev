﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using Cat.WebServices;
using System.Web;
using Coolant.BLL.ViewModels;

namespace Coolant.BLL.Contexts
{
    public class CurrentUserContext
    {
   
        /// <summary>
        /// Current user's CWS ID
        /// </summary>
        private string _currentUserCwsId;

        /// <summary>
        /// Current user
        /// </summary>
        public readonly UsersVM CurrentUser;

        /// <summary>
        /// Evaluate if current user is added to CWS group
        /// </summary>
        public bool HasAdminRights;
        public bool IsAllowed;

        public IdentityDirectoryQuery query = new IdentityDirectoryQuery();


        /// <summary>
        /// Constructor
        /// </summary>
        public UsersVM GetCurrentUser()
        {
            _currentUserCwsId = HttpContext.Current.User.Identity.Name.Trim().ToLower();

            Person Person = new Person();
            Person = query.GetPersonByLogonId(_currentUserCwsId);
 
            UsersVM CurrentUser = new UsersVM();
   

            return CurrentUser;
        }
  
    }
}
