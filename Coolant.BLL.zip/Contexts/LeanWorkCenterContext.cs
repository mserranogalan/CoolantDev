﻿using System;
using System.Web;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using Coolant.DAL.Repositories;
using Coolant.DAL.Model;
using Coolant.BLL.ViewModels;

namespace Coolant.BLL.Contexts
{
    public class LeanWorkCenterContext
    {
        /// <summary>
        /// Current user's CWS ID
        /// </summary>
        private readonly string _currentUserBadge = HttpContext.Current.User.Identity.Name;

        /// <summary>
        /// Usage of repositories
        /// </summary>
        private readonly LeanWorkCenterRepository _leanWorkCenterRepository;
        private CurrentUserContext currentUser = new CurrentUserContext();
        public ResponseVM _response;

        /// <summary>
        /// Constructor
        /// </summary>
        public LeanWorkCenterContext()
        {
            _leanWorkCenterRepository = new LeanWorkCenterRepository();
            _response = new ResponseVM();
        }

        /// <summary>
        /// Method to get a list of Lean Work Center
        /// </summary>
        /// <returns></returns>
        public List<LeanWorkCenterVM> GetAllLeanWorkCenter()
        {
            List<LeanWorkCenter> entityList = _leanWorkCenterRepository.GetAllLeanWorkCenter();
            List<LeanWorkCenterVM> viewModelList = entityList.ToLeanWorkCenterVMList();
            return viewModelList;
        }

        public ResponseVM UpdateLeanWorkCenter(LeanWorkCenterVM leanWorkCenter)
        {
            LeanWorkCenter leanWorkCenterTbl = new LeanWorkCenter
            {
                LeanWorkCenterId = leanWorkCenter.LeanWorkCenterId,
                Description = leanWorkCenter.Description,
                IsActive = leanWorkCenter.IsActive
            };

            leanWorkCenterTbl = _leanWorkCenterRepository.UpdateLeanWorkCenter(leanWorkCenterTbl);
            _response.Content = leanWorkCenterTbl.ToLeanWorkCenterVM();
            _response.Message = leanWorkCenterTbl != null ? "Lean Work Center updated" : "Lean Work Center was not updated";
            return _response;
        }


        public ResponseVM AddLeanWorkCEnter(LeanWorkCenterVM leanWorkCenter)
        {
            LeanWorkCenter leanWorkCenterTbl = new LeanWorkCenter
            {
                Description = leanWorkCenter.Description,
                IsActive = leanWorkCenter.IsActive
            };

            bool result = _leanWorkCenterRepository.AddLeanWorkCEnter(leanWorkCenterTbl);
            _response.Content = result ? leanWorkCenterTbl.ToLeanWorkCenterVM() : null;
            _response.Message = result ? "Lean Work Center Added" : "Lean Work Center was not Added";
            return _response;
        }


    }
}