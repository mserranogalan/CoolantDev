﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Text.RegularExpressions;
using Coolant.DAL.Repositories;
using Coolant.DAL.Model;
using Coolant.BLL.ViewModels;

namespace Coolant.BLL.Contexts
{
    public class UsersContext
    {
        /// <summary>
        /// Current user's CWS ID
        /// </summary>
        private readonly string _currentUserBadge = HttpContext.Current.User.Identity.Name;

        /// <summary>
        /// Usage of repositories
        /// </summary>
        private readonly UsersRepository _usersRepository;
        private CurrentUserContext currentUser = new CurrentUserContext();
        public ResponseVM _response;

        /// <summary>
        /// Constructor
        /// </summary>
        public UsersContext()
        {
            _usersRepository = new UsersRepository();
            _response = new ResponseVM();
        }

        /// <summary>
        /// Method to get a list of Users
        /// </summary>
        /// <returns></returns>
        public List<UsersVM> GetAllUsers()
        {
            List<Users> entityList = _usersRepository.GetAllUsers();
            List<UsersVM> viewModelList = entityList.ToUsersVMList();
            return viewModelList;
        }


        public ResponseVM UpdateUsers(UsersVM users)
        {
            Users usersTbl = new Users
            {
                UserId = users.UserId,
                Badge = users.Badge,
                Name = users.Name,
                LeanWorkCenterId = users.LeanWorkCenterId,
                RolId = users.RolId,
                SupervisorId = users.SupervisorId,
                IsActive = users.IsActive
            };

            usersTbl = _usersRepository.UpdateUsers(usersTbl);
            _response.Content = usersTbl.ToUsersVM();
            _response.Message = usersTbl != null ? "The User updated" : "The User was not updated";
            return _response;
        }


        public ResponseVM AddUser(UsersVM users)
        {
            Users usersTbl = new Users
            {
                Badge = users.Badge,
                Name = users.Name,
                LeanWorkCenterId = users.LeanWorkCenterId,
                RolId = users.RolId,
                SupervisorId = users.SupervisorId,
                IsActive = users.IsActive
            };

            bool result = _usersRepository.AddUser(usersTbl);
            _response.Content = result ? usersTbl.ToUsersVM() : null;
            _response.Message = result ? "The User Added" : "The User was not Added";
            return _response;
        }


    }
}
