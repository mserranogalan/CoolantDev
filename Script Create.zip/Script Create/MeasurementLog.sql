USE [CoolantDB]
GO

/****** Object:  Table [dbo].[MeasurementLog]    Script Date: 4/3/2019 11:37:17 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[MeasurementLog](
	[MeasurementLogId] [int] IDENTITY(1,1) NOT NULL,
	[MachineId] [int] NOT NULL,
	[CreatedBy] [int] NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ConcentrationValue] [decimal](10, 2) NOT NULL,
	[MinConcentration] [decimal](10, 0) NOT NULL,
	[MaxConcentration] [decimal](10, 0) NOT NULL,
	[NewConcentrationValue] [decimal](10, 0) NOT NULL,
	[ConcentrationActionTaken] [nvarchar](250) NULL,
	[PHValue] [decimal](10, 0) NOT NULL,
	[MinPHValue] [decimal](10, 0) NULL,
	[MaxPHValue] [decimal](10, 0) NULL,
	[NewPHValue] [decimal](10, 0) NULL,
	[PHActionTaken] [nvarchar](250) NULL,
	[CoolantLevel] [bit] NOT NULL,
	[CoolantLevelFixed] [bit] NULL,
	[RustPresent] [bit] NOT NULL,
	[BadSmell] [bit] NOT NULL,
	[Comments] [nvarchar](250) NULL,
	[UserId] [int] NOT NULL,
	[AuthorizedOn] [datetime] NOT NULL,
 CONSTRAINT [PK_MeasurementLog] PRIMARY KEY CLUSTERED 
(
	[MeasurementLogId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


