USE [CoolantDB]
GO

/****** Object:  Table [dbo].[AuditLogRecords]    Script Date: 4/3/2019 11:36:50 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AuditLogRecords](
	[AuditLogRecordId] [int] IDENTITY(1,1) NOT NULL,
	[AuditLogId] [int] NOT NULL,
	[ColumnName] [nvarchar](255) NOT NULL,
	[OriginalValue] [nvarchar](4000) NULL,
	[NewValue] [nvarchar](4000) NULL,
 CONSTRAINT [PK_AuditLogRecords] PRIMARY KEY CLUSTERED 
(
	[AuditLogRecordId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


